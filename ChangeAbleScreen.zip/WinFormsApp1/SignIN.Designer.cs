﻿namespace WinFormsApp1
{
    partial class SignIN
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SignIN));
            lblSignUp = new Label();
            rdbtnMale = new RadioButton();
            rdbtnFemale = new RadioButton();
            lblGender = new Label();
            txtbxName = new TextBox();
            lblName = new Label();
            tableLayoutPanel12 = new TableLayoutPanel();
            lblRecordSignal = new Label();
            tableLayoutPanel13 = new TableLayoutPanel();
            lblConfirmPasswordSignal = new Label();
            lbAssigned = new Label();
            lblConfirmPassword = new Label();
            tableLayoutPanel18 = new TableLayoutPanel();
            cmbxAssigned = new ComboBox();
            tableLayoutPanel15 = new TableLayoutPanel();
            txtbxConfirmPassword = new TextBox();
            lblHomeAddress = new Label();
            btnShowPasswrd2 = new Button();
            tableLayoutPanel17 = new TableLayoutPanel();
            rtxtbxHomeAddress = new RichTextBox();
            lblHomeAddressSignal = new Label();
            tableLayoutPanel14 = new TableLayoutPanel();
            btnClose = new Button();
            btnClear = new Button();
            btnCreateAccount = new Button();
            tableLayoutPanel16 = new TableLayoutPanel();
            tableLayoutPanel11 = new TableLayoutPanel();
            tableLayoutPanel1 = new TableLayoutPanel();
            gbx = new GroupBox();
            tableLayoutPanel2 = new TableLayoutPanel();
            tableLayoutPanel3 = new TableLayoutPanel();
            tableLayoutPanel10 = new TableLayoutPanel();
            lblNewPasswordSignal = new Label();
            lblEmailAddressSignal = new Label();
            tableLayoutPanel6 = new TableLayoutPanel();
            txtbxNewPassowrd = new TextBox();
            lblNewPassword = new Label();
            btnShowPassword = new Button();
            lblEmailAddress = new Label();
            txtbxEmailAddress = new TextBox();
            tableLayoutPanel4 = new TableLayoutPanel();
            lblDesignation = new Label();
            cmbxDesignation = new ComboBox();
            lblCNIC = new Label();
            txtbxCNIC = new TextBox();
            tableLayoutPanel5 = new TableLayoutPanel();
            lblUsername = new Label();
            txtbxUsername = new TextBox();
            txtbxContactNumber = new TextBox();
            lblContactNumber = new Label();
            tableLayoutPanel7 = new TableLayoutPanel();
            lblDesignationSingal = new Label();
            lblCNICSignal = new Label();
            tableLayoutPanel8 = new TableLayoutPanel();
            lblGenderSignal = new Label();
            lblNameSignal = new Label();
            tableLayoutPanel9 = new TableLayoutPanel();
            lblContactNumberSignal = new Label();
            lblUsernameSignal = new Label();
            tableLayoutPanel12.SuspendLayout();
            tableLayoutPanel13.SuspendLayout();
            tableLayoutPanel18.SuspendLayout();
            tableLayoutPanel15.SuspendLayout();
            tableLayoutPanel17.SuspendLayout();
            tableLayoutPanel14.SuspendLayout();
            tableLayoutPanel16.SuspendLayout();
            tableLayoutPanel11.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            gbx.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            tableLayoutPanel10.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            tableLayoutPanel7.SuspendLayout();
            tableLayoutPanel8.SuspendLayout();
            tableLayoutPanel9.SuspendLayout();
            SuspendLayout();
            // 
            // lblSignUp
            // 
            lblSignUp.AutoSize = true;
            lblSignUp.Font = new Font("Microsoft Sans Serif", 23F, FontStyle.Bold, GraphicsUnit.Point);
            lblSignUp.Location = new Point(340, 0);
            lblSignUp.Name = "lblSignUp";
            lblSignUp.Size = new Size(122, 31);
            lblSignUp.TabIndex = 0;
            lblSignUp.Text = "SignUp";
            // 
            // rdbtnMale
            // 
            rdbtnMale.AutoSize = true;
            rdbtnMale.Checked = true;
            rdbtnMale.Location = new Point(551, 3);
            rdbtnMale.Name = "rdbtnMale";
            rdbtnMale.Size = new Size(51, 19);
            rdbtnMale.TabIndex = 6;
            rdbtnMale.TabStop = true;
            rdbtnMale.Text = "Male";
            rdbtnMale.UseVisualStyleBackColor = true;
            // 
            // rdbtnFemale
            // 
            rdbtnFemale.AutoSize = true;
            rdbtnFemale.Location = new Point(624, 3);
            rdbtnFemale.Name = "rdbtnFemale";
            rdbtnFemale.Size = new Size(63, 19);
            rdbtnFemale.TabIndex = 7;
            rdbtnFemale.TabStop = true;
            rdbtnFemale.Text = "Female";
            rdbtnFemale.UseVisualStyleBackColor = true;
            // 
            // lblGender
            // 
            lblGender.AutoSize = true;
            lblGender.Location = new Point(377, 0);
            lblGender.Name = "lblGender";
            lblGender.Size = new Size(51, 15);
            lblGender.TabIndex = 2;
            lblGender.Text = "Gender :";
            // 
            // txtbxName
            // 
            txtbxName.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            txtbxName.Location = new Point(157, 3);
            txtbxName.Name = "txtbxName";
            txtbxName.Size = new Size(203, 25);
            txtbxName.TabIndex = 1;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(3, 0);
            lblName.Name = "lblName";
            lblName.Size = new Size(48, 15);
            lblName.TabIndex = 2;
            lblName.Text = " Name :";
            // 
            // tableLayoutPanel12
            // 
            tableLayoutPanel12.ColumnCount = 2;
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65.35245F));
            tableLayoutPanel12.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.64755F));
            tableLayoutPanel12.Controls.Add(lblRecordSignal, 0, 1);
            tableLayoutPanel12.Controls.Add(tableLayoutPanel13, 0, 0);
            tableLayoutPanel12.Controls.Add(tableLayoutPanel17, 1, 0);
            tableLayoutPanel12.Dock = DockStyle.Fill;
            tableLayoutPanel12.Location = new Point(79, 233);
            tableLayoutPanel12.Name = "tableLayoutPanel12";
            tableLayoutPanel12.RowCount = 2;
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 81.19658F));
            tableLayoutPanel12.RowStyles.Add(new RowStyle(SizeType.Percent, 18.80342F));
            tableLayoutPanel12.Size = new Size(836, 141);
            tableLayoutPanel12.TabIndex = 8;
            // 
            // lblRecordSignal
            // 
            lblRecordSignal.AutoSize = true;
            lblRecordSignal.Location = new Point(3, 114);
            lblRecordSignal.Name = "lblRecordSignal";
            lblRecordSignal.Size = new Size(10, 15);
            lblRecordSignal.TabIndex = 33;
            lblRecordSignal.Text = " ";
            // 
            // tableLayoutPanel13
            // 
            tableLayoutPanel13.ColumnCount = 2;
            tableLayoutPanel13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26.80222F));
            tableLayoutPanel13.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 73.19778F));
            tableLayoutPanel13.Controls.Add(lblConfirmPasswordSignal, 1, 1);
            tableLayoutPanel13.Controls.Add(lbAssigned, 0, 2);
            tableLayoutPanel13.Controls.Add(lblConfirmPassword, 0, 0);
            tableLayoutPanel13.Controls.Add(tableLayoutPanel18, 1, 2);
            tableLayoutPanel13.Controls.Add(tableLayoutPanel15, 1, 0);
            tableLayoutPanel13.Dock = DockStyle.Fill;
            tableLayoutPanel13.Location = new Point(3, 3);
            tableLayoutPanel13.Name = "tableLayoutPanel13";
            tableLayoutPanel13.RowCount = 3;
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 30.2521F));
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 21.0084F));
            tableLayoutPanel13.RowStyles.Add(new RowStyle(SizeType.Percent, 48.73949F));
            tableLayoutPanel13.Size = new Size(540, 108);
            tableLayoutPanel13.TabIndex = 34;
            // 
            // lblConfirmPasswordSignal
            // 
            lblConfirmPasswordSignal.AutoSize = true;
            lblConfirmPasswordSignal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblConfirmPasswordSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblConfirmPasswordSignal.Location = new Point(147, 32);
            lblConfirmPasswordSignal.Name = "lblConfirmPasswordSignal";
            lblConfirmPasswordSignal.Size = new Size(13, 20);
            lblConfirmPasswordSignal.TabIndex = 22;
            lblConfirmPasswordSignal.Text = " ";
            // 
            // lbAssigned
            // 
            lbAssigned.AutoSize = true;
            lbAssigned.Location = new Point(3, 54);
            lbAssigned.Name = "lbAssigned";
            lbAssigned.Size = new Size(72, 15);
            lbAssigned.TabIndex = 35;
            lbAssigned.Text = "Warehouse :";
            // 
            // lblConfirmPassword
            // 
            lblConfirmPassword.AutoSize = true;
            lblConfirmPassword.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblConfirmPassword.Location = new Point(3, 0);
            lblConfirmPassword.Name = "lblConfirmPassword";
            lblConfirmPassword.Size = new Size(137, 32);
            lblConfirmPassword.TabIndex = 2;
            lblConfirmPassword.Text = "Confirm Password :";
            // 
            // tableLayoutPanel18
            // 
            tableLayoutPanel18.ColumnCount = 1;
            tableLayoutPanel18.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel18.Controls.Add(cmbxAssigned, 0, 0);
            tableLayoutPanel18.Dock = DockStyle.Fill;
            tableLayoutPanel18.Location = new Point(147, 57);
            tableLayoutPanel18.Name = "tableLayoutPanel18";
            tableLayoutPanel18.RowCount = 1;
            tableLayoutPanel18.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel18.Size = new Size(390, 48);
            tableLayoutPanel18.TabIndex = 14;
            // 
            // cmbxAssigned
            // 
            cmbxAssigned.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbxAssigned.FlatStyle = FlatStyle.Flat;
            cmbxAssigned.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            cmbxAssigned.FormattingEnabled = true;
            cmbxAssigned.Location = new Point(3, 3);
            cmbxAssigned.Name = "cmbxAssigned";
            cmbxAssigned.Size = new Size(183, 26);
            cmbxAssigned.Sorted = true;
            cmbxAssigned.TabIndex = 11;
            // 
            // tableLayoutPanel15
            // 
            tableLayoutPanel15.ColumnCount = 3;
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 47.94872F));
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 10.05155F));
            tableLayoutPanel15.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 42.01031F));
            tableLayoutPanel15.Controls.Add(txtbxConfirmPassword, 0, 0);
            tableLayoutPanel15.Controls.Add(lblHomeAddress, 2, 0);
            tableLayoutPanel15.Controls.Add(btnShowPasswrd2, 1, 0);
            tableLayoutPanel15.Dock = DockStyle.Fill;
            tableLayoutPanel15.Location = new Point(147, 3);
            tableLayoutPanel15.Name = "tableLayoutPanel15";
            tableLayoutPanel15.RowCount = 1;
            tableLayoutPanel15.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel15.Size = new Size(390, 26);
            tableLayoutPanel15.TabIndex = 0;
            // 
            // txtbxConfirmPassword
            // 
            txtbxConfirmPassword.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            txtbxConfirmPassword.Location = new Point(3, 3);
            txtbxConfirmPassword.Name = "txtbxConfirmPassword";
            txtbxConfirmPassword.Size = new Size(179, 25);
            txtbxConfirmPassword.TabIndex = 4;
            txtbxConfirmPassword.UseSystemPasswordChar = true;
            // 
            // lblHomeAddress
            // 
            lblHomeAddress.AutoSize = true;
            lblHomeAddress.Location = new Point(228, 0);
            lblHomeAddress.Name = "lblHomeAddress";
            lblHomeAddress.Size = new Size(91, 15);
            lblHomeAddress.TabIndex = 2;
            lblHomeAddress.Text = "Home Address :";
            // 
            // btnShowPasswrd2
            // 
            btnShowPasswrd2.FlatAppearance.BorderSize = 0;
            btnShowPasswrd2.FlatStyle = FlatStyle.Flat;
            btnShowPasswrd2.Image = (Image)resources.GetObject("btnShowPasswrd2.Image");
            btnShowPasswrd2.Location = new Point(189, 3);
            btnShowPasswrd2.Name = "btnShowPasswrd2";
            btnShowPasswrd2.Size = new Size(20, 20);
            btnShowPasswrd2.TabIndex = 32;
            btnShowPasswrd2.UseVisualStyleBackColor = true;
            // 
            // tableLayoutPanel17
            // 
            tableLayoutPanel17.ColumnCount = 1;
            tableLayoutPanel17.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel17.Controls.Add(rtxtbxHomeAddress, 0, 0);
            tableLayoutPanel17.Controls.Add(lblHomeAddressSignal, 0, 1);
            tableLayoutPanel17.Dock = DockStyle.Fill;
            tableLayoutPanel17.Location = new Point(549, 3);
            tableLayoutPanel17.Name = "tableLayoutPanel17";
            tableLayoutPanel17.RowCount = 2;
            tableLayoutPanel17.RowStyles.Add(new RowStyle(SizeType.Percent, 52.10084F));
            tableLayoutPanel17.RowStyles.Add(new RowStyle(SizeType.Percent, 47.89916F));
            tableLayoutPanel17.Size = new Size(284, 108);
            tableLayoutPanel17.TabIndex = 14;
            // 
            // rtxtbxHomeAddress
            // 
            rtxtbxHomeAddress.BorderStyle = BorderStyle.None;
            rtxtbxHomeAddress.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            rtxtbxHomeAddress.Location = new Point(3, 3);
            rtxtbxHomeAddress.Name = "rtxtbxHomeAddress";
            rtxtbxHomeAddress.Size = new Size(203, 50);
            rtxtbxHomeAddress.TabIndex = 10;
            rtxtbxHomeAddress.Text = "";
            // 
            // lblHomeAddressSignal
            // 
            lblHomeAddressSignal.AutoSize = true;
            lblHomeAddressSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblHomeAddressSignal.Location = new Point(3, 56);
            lblHomeAddressSignal.Name = "lblHomeAddressSignal";
            lblHomeAddressSignal.Size = new Size(10, 15);
            lblHomeAddressSignal.TabIndex = 30;
            lblHomeAddressSignal.Text = " ";
            // 
            // tableLayoutPanel14
            // 
            tableLayoutPanel14.ColumnCount = 4;
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14.91228F));
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23.02632F));
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 23.46491F));
            tableLayoutPanel14.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 38.48684F));
            tableLayoutPanel14.Controls.Add(btnClose, 1, 0);
            tableLayoutPanel14.Controls.Add(btnClear, 2, 0);
            tableLayoutPanel14.Controls.Add(btnCreateAccount, 3, 0);
            tableLayoutPanel14.Dock = DockStyle.Fill;
            tableLayoutPanel14.Location = new Point(3, 423);
            tableLayoutPanel14.Name = "tableLayoutPanel14";
            tableLayoutPanel14.RowCount = 1;
            tableLayoutPanel14.RowStyles.Add(new RowStyle(SizeType.Percent, 85.96491F));
            tableLayoutPanel14.Size = new Size(918, 41);
            tableLayoutPanel14.TabIndex = 1;
            // 
            // btnClose
            // 
            btnClose.BackColor = Color.FromArgb(200, 37, 48);
            btnClose.FlatAppearance.BorderColor = Color.Black;
            btnClose.FlatStyle = FlatStyle.Flat;
            btnClose.ForeColor = Color.White;
            btnClose.Location = new Point(140, 3);
            btnClose.Name = "btnClose";
            btnClose.Size = new Size(200, 30);
            btnClose.TabIndex = 12;
            btnClose.Text = "Close";
            btnClose.UseVisualStyleBackColor = false;
            // 
            // btnClear
            // 
            btnClear.BackColor = Color.FromArgb(14, 97, 139);
            btnClear.FlatAppearance.BorderColor = Color.Black;
            btnClear.FlatStyle = FlatStyle.Flat;
            btnClear.ForeColor = Color.White;
            btnClear.Location = new Point(351, 3);
            btnClear.Name = "btnClear";
            btnClear.Size = new Size(200, 30);
            btnClear.TabIndex = 13;
            btnClear.Text = "Clear All";
            btnClear.UseVisualStyleBackColor = false;
            // 
            // btnCreateAccount
            // 
            btnCreateAccount.BackColor = Color.FromArgb(25, 100, 26);
            btnCreateAccount.FlatAppearance.BorderColor = Color.Black;
            btnCreateAccount.FlatStyle = FlatStyle.Flat;
            btnCreateAccount.ForeColor = Color.White;
            btnCreateAccount.Location = new Point(566, 3);
            btnCreateAccount.Name = "btnCreateAccount";
            btnCreateAccount.Size = new Size(200, 30);
            btnCreateAccount.TabIndex = 14;
            btnCreateAccount.Text = "Create Account";
            btnCreateAccount.UseVisualStyleBackColor = false;
            // 
            // tableLayoutPanel16
            // 
            tableLayoutPanel16.ColumnCount = 2;
            tableLayoutPanel16.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 36.73246F));
            tableLayoutPanel16.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 63.26754F));
            tableLayoutPanel16.Controls.Add(lblSignUp, 1, 0);
            tableLayoutPanel16.Dock = DockStyle.Fill;
            tableLayoutPanel16.Location = new Point(3, 3);
            tableLayoutPanel16.Name = "tableLayoutPanel16";
            tableLayoutPanel16.RowCount = 1;
            tableLayoutPanel16.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel16.Size = new Size(918, 31);
            tableLayoutPanel16.TabIndex = 2;
            // 
            // tableLayoutPanel11
            // 
            tableLayoutPanel11.ColumnCount = 5;
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.41155F));
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26.35379F));
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20.78853F));
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 8.721624F));
            tableLayoutPanel11.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25.5675F));
            tableLayoutPanel11.Controls.Add(rdbtnMale, 3, 0);
            tableLayoutPanel11.Controls.Add(rdbtnFemale, 4, 0);
            tableLayoutPanel11.Controls.Add(lblGender, 2, 0);
            tableLayoutPanel11.Controls.Add(txtbxName, 1, 0);
            tableLayoutPanel11.Controls.Add(lblName, 0, 0);
            tableLayoutPanel11.Dock = DockStyle.Fill;
            tableLayoutPanel11.Location = new Point(79, 66);
            tableLayoutPanel11.Name = "tableLayoutPanel11";
            tableLayoutPanel11.RowCount = 1;
            tableLayoutPanel11.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel11.Size = new Size(836, 26);
            tableLayoutPanel11.TabIndex = 7;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(gbx, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Fill;
            tableLayoutPanel1.Location = new Point(0, 0);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(936, 495);
            tableLayoutPanel1.TabIndex = 2;
            // 
            // gbx
            // 
            gbx.Controls.Add(tableLayoutPanel2);
            gbx.Dock = DockStyle.Fill;
            gbx.Location = new Point(3, 3);
            gbx.Name = "gbx";
            gbx.Size = new Size(930, 489);
            gbx.TabIndex = 0;
            gbx.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 1;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel2.Controls.Add(tableLayoutPanel3, 0, 1);
            tableLayoutPanel2.Controls.Add(tableLayoutPanel14, 0, 2);
            tableLayoutPanel2.Controls.Add(tableLayoutPanel16, 0, 0);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 19);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 3;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 8.05501F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 82.31827F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 9.823183F));
            tableLayoutPanel2.Size = new Size(924, 467);
            tableLayoutPanel2.TabIndex = 36;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 2;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 8.333333F));
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 91.66666F));
            tableLayoutPanel3.Controls.Add(tableLayoutPanel10, 1, 8);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel6, 1, 7);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel4, 1, 1);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel5, 1, 5);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel7, 1, 2);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel8, 1, 4);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel9, 1, 6);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel11, 1, 3);
            tableLayoutPanel3.Controls.Add(tableLayoutPanel12, 1, 9);
            tableLayoutPanel3.Dock = DockStyle.Fill;
            tableLayoutPanel3.Location = new Point(3, 40);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 10;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 2.031778F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 9.11271F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 6.310679F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 8.737864F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 6.067961F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 8.980582F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 5.825243F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 9.223301F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 6.796116F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 38.83495F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel3.Size = new Size(918, 377);
            tableLayoutPanel3.TabIndex = 0;
            // 
            // tableLayoutPanel10
            // 
            tableLayoutPanel10.ColumnCount = 3;
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.17088F));
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 47.29242F));
            tableLayoutPanel10.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.4086F));
            tableLayoutPanel10.Controls.Add(lblNewPasswordSignal, 1, 0);
            tableLayoutPanel10.Controls.Add(lblEmailAddressSignal, 2, 0);
            tableLayoutPanel10.Dock = DockStyle.Fill;
            tableLayoutPanel10.Location = new Point(79, 208);
            tableLayoutPanel10.Name = "tableLayoutPanel10";
            tableLayoutPanel10.RowCount = 1;
            tableLayoutPanel10.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel10.Size = new Size(836, 19);
            tableLayoutPanel10.TabIndex = 6;
            // 
            // lblNewPasswordSignal
            // 
            lblNewPasswordSignal.AutoSize = true;
            lblNewPasswordSignal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblNewPasswordSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblNewPasswordSignal.Location = new Point(155, 0);
            lblNewPasswordSignal.Name = "lblNewPasswordSignal";
            lblNewPasswordSignal.Size = new Size(13, 19);
            lblNewPasswordSignal.TabIndex = 21;
            lblNewPasswordSignal.Text = " ";
            // 
            // lblEmailAddressSignal
            // 
            lblEmailAddressSignal.AutoSize = true;
            lblEmailAddressSignal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblEmailAddressSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblEmailAddressSignal.Location = new Point(550, 0);
            lblEmailAddressSignal.Name = "lblEmailAddressSignal";
            lblEmailAddressSignal.Size = new Size(13, 19);
            lblEmailAddressSignal.TabIndex = 25;
            lblEmailAddressSignal.Text = " ";
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.ColumnCount = 5;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.05054F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 21.90132F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 5.174489F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19.97593F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.64755F));
            tableLayoutPanel6.Controls.Add(txtbxNewPassowrd, 1, 0);
            tableLayoutPanel6.Controls.Add(lblNewPassword, 0, 0);
            tableLayoutPanel6.Controls.Add(btnShowPassword, 2, 0);
            tableLayoutPanel6.Controls.Add(lblEmailAddress, 3, 0);
            tableLayoutPanel6.Controls.Add(txtbxEmailAddress, 4, 0);
            tableLayoutPanel6.Dock = DockStyle.Fill;
            tableLayoutPanel6.Location = new Point(79, 174);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 1;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel6.Size = new Size(836, 28);
            tableLayoutPanel6.TabIndex = 2;
            // 
            // txtbxNewPassowrd
            // 
            txtbxNewPassowrd.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            txtbxNewPassowrd.Location = new Point(154, 3);
            txtbxNewPassowrd.Name = "txtbxNewPassowrd";
            txtbxNewPassowrd.Size = new Size(176, 25);
            txtbxNewPassowrd.TabIndex = 3;
            txtbxNewPassowrd.UseSystemPasswordChar = true;
            // 
            // lblNewPassword
            // 
            lblNewPassword.AutoSize = true;
            lblNewPassword.Location = new Point(3, 0);
            lblNewPassword.Name = "lblNewPassword";
            lblNewPassword.Size = new Size(93, 15);
            lblNewPassword.TabIndex = 2;
            lblNewPassword.Text = " New Password :";
            // 
            // btnShowPassword
            // 
            btnShowPassword.FlatAppearance.BorderSize = 0;
            btnShowPassword.FlatStyle = FlatStyle.Flat;
            btnShowPassword.Image = (Image)resources.GetObject("btnShowPassword.Image");
            btnShowPassword.Location = new Point(337, 3);
            btnShowPassword.Name = "btnShowPassword";
            btnShowPassword.Size = new Size(20, 22);
            btnShowPassword.TabIndex = 31;
            btnShowPassword.UseVisualStyleBackColor = true;
            // 
            // lblEmailAddress
            // 
            lblEmailAddress.AutoSize = true;
            lblEmailAddress.Location = new Point(380, 0);
            lblEmailAddress.Name = "lblEmailAddress";
            lblEmailAddress.Size = new Size(87, 15);
            lblEmailAddress.TabIndex = 2;
            lblEmailAddress.Text = "Email Address :";
            // 
            // txtbxEmailAddress
            // 
            txtbxEmailAddress.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            txtbxEmailAddress.Location = new Point(547, 3);
            txtbxEmailAddress.Name = "txtbxEmailAddress";
            txtbxEmailAddress.Size = new Size(203, 25);
            txtbxEmailAddress.TabIndex = 9;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.ColumnCount = 4;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.53189F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25.99278F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20.78853F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.52808F));
            tableLayoutPanel4.Controls.Add(lblDesignation, 0, 0);
            tableLayoutPanel4.Controls.Add(cmbxDesignation, 1, 0);
            tableLayoutPanel4.Controls.Add(lblCNIC, 2, 0);
            tableLayoutPanel4.Controls.Add(txtbxCNIC, 3, 0);
            tableLayoutPanel4.Dock = DockStyle.Fill;
            tableLayoutPanel4.Location = new Point(79, 10);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 1;
            tableLayoutPanel4.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel4.Size = new Size(836, 27);
            tableLayoutPanel4.TabIndex = 0;
            // 
            // lblDesignation
            // 
            lblDesignation.AutoSize = true;
            lblDesignation.Location = new Point(3, 0);
            lblDesignation.Name = "lblDesignation";
            lblDesignation.Size = new Size(79, 15);
            lblDesignation.TabIndex = 2;
            lblDesignation.Text = " Designation :";
            // 
            // cmbxDesignation
            // 
            cmbxDesignation.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbxDesignation.FlatStyle = FlatStyle.Flat;
            cmbxDesignation.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            cmbxDesignation.FormattingEnabled = true;
            cmbxDesignation.Items.AddRange(new object[] { "CEO", "Employee", "Rider", "Warehouse Manager" });
            cmbxDesignation.Location = new Point(158, 3);
            cmbxDesignation.Name = "cmbxDesignation";
            cmbxDesignation.Size = new Size(203, 26);
            cmbxDesignation.Sorted = true;
            cmbxDesignation.TabIndex = 0;
            // 
            // lblCNIC
            // 
            lblCNIC.AutoSize = true;
            lblCNIC.Location = new Point(375, 0);
            lblCNIC.Name = "lblCNIC";
            lblCNIC.Size = new Size(41, 15);
            lblCNIC.TabIndex = 2;
            lblCNIC.Text = "CNIC :";
            // 
            // txtbxCNIC
            // 
            txtbxCNIC.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            txtbxCNIC.Location = new Point(549, 3);
            txtbxCNIC.Name = "txtbxCNIC";
            txtbxCNIC.Size = new Size(203, 25);
            txtbxCNIC.TabIndex = 5;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 4;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.17088F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26.83514F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20.33694F));
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.52808F));
            tableLayoutPanel5.Controls.Add(lblUsername, 0, 0);
            tableLayoutPanel5.Controls.Add(txtbxUsername, 1, 0);
            tableLayoutPanel5.Controls.Add(txtbxContactNumber, 3, 0);
            tableLayoutPanel5.Controls.Add(lblContactNumber, 2, 0);
            tableLayoutPanel5.Dock = DockStyle.Fill;
            tableLayoutPanel5.Location = new Point(79, 120);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 1;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel5.Size = new Size(836, 27);
            tableLayoutPanel5.TabIndex = 1;
            // 
            // lblUsername
            // 
            lblUsername.AutoSize = true;
            lblUsername.Location = new Point(3, 0);
            lblUsername.Name = "lblUsername";
            lblUsername.Size = new Size(72, 15);
            lblUsername.TabIndex = 2;
            lblUsername.Text = " User name :";
            // 
            // txtbxUsername
            // 
            txtbxUsername.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            txtbxUsername.Location = new Point(155, 3);
            txtbxUsername.Name = "txtbxUsername";
            txtbxUsername.Size = new Size(203, 25);
            txtbxUsername.TabIndex = 2;
            // 
            // txtbxContactNumber
            // 
            txtbxContactNumber.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            txtbxContactNumber.Location = new Point(549, 3);
            txtbxContactNumber.Name = "txtbxContactNumber";
            txtbxContactNumber.Size = new Size(203, 25);
            txtbxContactNumber.TabIndex = 8;
            // 
            // lblContactNumber
            // 
            lblContactNumber.AutoSize = true;
            lblContactNumber.Location = new Point(379, 0);
            lblContactNumber.Name = "lblContactNumber";
            lblContactNumber.Size = new Size(102, 15);
            lblContactNumber.TabIndex = 2;
            lblContactNumber.Text = "Conatct Number :";
            // 
            // tableLayoutPanel7
            // 
            tableLayoutPanel7.ColumnCount = 3;
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.65223F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 46.81107F));
            tableLayoutPanel7.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.4086F));
            tableLayoutPanel7.Controls.Add(lblDesignationSingal, 1, 0);
            tableLayoutPanel7.Controls.Add(lblCNICSignal, 2, 0);
            tableLayoutPanel7.Dock = DockStyle.Fill;
            tableLayoutPanel7.Location = new Point(79, 43);
            tableLayoutPanel7.Name = "tableLayoutPanel7";
            tableLayoutPanel7.RowCount = 1;
            tableLayoutPanel7.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel7.Size = new Size(836, 17);
            tableLayoutPanel7.TabIndex = 3;
            // 
            // lblDesignationSingal
            // 
            lblDesignationSingal.AutoSize = true;
            lblDesignationSingal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblDesignationSingal.ForeColor = Color.FromArgb(200, 37, 48);
            lblDesignationSingal.Location = new Point(159, 0);
            lblDesignationSingal.Name = "lblDesignationSingal";
            lblDesignationSingal.Size = new Size(13, 17);
            lblDesignationSingal.TabIndex = 1;
            lblDesignationSingal.Text = " ";
            // 
            // lblCNICSignal
            // 
            lblCNICSignal.AutoSize = true;
            lblCNICSignal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblCNICSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblCNICSignal.Location = new Point(550, 0);
            lblCNICSignal.Name = "lblCNICSignal";
            lblCNICSignal.Size = new Size(13, 17);
            lblCNICSignal.TabIndex = 18;
            lblCNICSignal.Text = " ";
            // 
            // tableLayoutPanel8
            // 
            tableLayoutPanel8.ColumnCount = 3;
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.41155F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 47.05175F));
            tableLayoutPanel8.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.4086F));
            tableLayoutPanel8.Controls.Add(lblGenderSignal, 2, 0);
            tableLayoutPanel8.Controls.Add(lblNameSignal, 1, 0);
            tableLayoutPanel8.Dock = DockStyle.Fill;
            tableLayoutPanel8.Location = new Point(79, 98);
            tableLayoutPanel8.Name = "tableLayoutPanel8";
            tableLayoutPanel8.RowCount = 1;
            tableLayoutPanel8.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel8.Size = new Size(836, 16);
            tableLayoutPanel8.TabIndex = 4;
            // 
            // lblGenderSignal
            // 
            lblGenderSignal.AutoSize = true;
            lblGenderSignal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblGenderSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblGenderSignal.Location = new Point(550, 0);
            lblGenderSignal.Name = "lblGenderSignal";
            lblGenderSignal.Size = new Size(13, 16);
            lblGenderSignal.TabIndex = 23;
            lblGenderSignal.Text = " ";
            // 
            // lblNameSignal
            // 
            lblNameSignal.AutoSize = true;
            lblNameSignal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblNameSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblNameSignal.Location = new Point(157, 0);
            lblNameSignal.Name = "lblNameSignal";
            lblNameSignal.Size = new Size(13, 16);
            lblNameSignal.TabIndex = 19;
            lblNameSignal.Text = " ";
            // 
            // tableLayoutPanel9
            // 
            tableLayoutPanel9.ColumnCount = 3;
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.17088F));
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 47.29242F));
            tableLayoutPanel9.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 34.4086F));
            tableLayoutPanel9.Controls.Add(lblContactNumberSignal, 2, 0);
            tableLayoutPanel9.Controls.Add(lblUsernameSignal, 1, 0);
            tableLayoutPanel9.Dock = DockStyle.Fill;
            tableLayoutPanel9.Location = new Point(79, 153);
            tableLayoutPanel9.Name = "tableLayoutPanel9";
            tableLayoutPanel9.RowCount = 1;
            tableLayoutPanel9.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel9.Size = new Size(836, 15);
            tableLayoutPanel9.TabIndex = 5;
            // 
            // lblContactNumberSignal
            // 
            lblContactNumberSignal.AutoSize = true;
            lblContactNumberSignal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblContactNumberSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblContactNumberSignal.Location = new Point(550, 0);
            lblContactNumberSignal.Name = "lblContactNumberSignal";
            lblContactNumberSignal.Size = new Size(13, 15);
            lblContactNumberSignal.TabIndex = 24;
            lblContactNumberSignal.Text = " ";
            // 
            // lblUsernameSignal
            // 
            lblUsernameSignal.AutoSize = true;
            lblUsernameSignal.Font = new Font("Microsoft Sans Serif", 11.5F, FontStyle.Regular, GraphicsUnit.Point);
            lblUsernameSignal.ForeColor = Color.FromArgb(200, 37, 48);
            lblUsernameSignal.Location = new Point(155, 0);
            lblUsernameSignal.Name = "lblUsernameSignal";
            lblUsernameSignal.Size = new Size(13, 15);
            lblUsernameSignal.TabIndex = 20;
            lblUsernameSignal.Text = " ";
            // 
            // SignIN
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(936, 495);
            Controls.Add(tableLayoutPanel1);
            Name = "SignIN";
            Text = "SignIN";
            tableLayoutPanel12.ResumeLayout(false);
            tableLayoutPanel12.PerformLayout();
            tableLayoutPanel13.ResumeLayout(false);
            tableLayoutPanel13.PerformLayout();
            tableLayoutPanel18.ResumeLayout(false);
            tableLayoutPanel15.ResumeLayout(false);
            tableLayoutPanel15.PerformLayout();
            tableLayoutPanel17.ResumeLayout(false);
            tableLayoutPanel17.PerformLayout();
            tableLayoutPanel14.ResumeLayout(false);
            tableLayoutPanel16.ResumeLayout(false);
            tableLayoutPanel16.PerformLayout();
            tableLayoutPanel11.ResumeLayout(false);
            tableLayoutPanel11.PerformLayout();
            tableLayoutPanel1.ResumeLayout(false);
            gbx.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel10.ResumeLayout(false);
            tableLayoutPanel10.PerformLayout();
            tableLayoutPanel6.ResumeLayout(false);
            tableLayoutPanel6.PerformLayout();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel4.PerformLayout();
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel5.PerformLayout();
            tableLayoutPanel7.ResumeLayout(false);
            tableLayoutPanel7.PerformLayout();
            tableLayoutPanel8.ResumeLayout(false);
            tableLayoutPanel8.PerformLayout();
            tableLayoutPanel9.ResumeLayout(false);
            tableLayoutPanel9.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label lblSignUp;
        private RadioButton rdbtnMale;
        private RadioButton rdbtnFemale;
        private Label lblGender;
        private TextBox txtbxName;
        private Label lblName;
        private TableLayoutPanel tableLayoutPanel12;
        private Label lblRecordSignal;
        private TableLayoutPanel tableLayoutPanel13;
        private Label lblConfirmPasswordSignal;
        private Label lbAssigned;
        private Label lblConfirmPassword;
        private TableLayoutPanel tableLayoutPanel18;
        private ComboBox cmbxAssigned;
        private TableLayoutPanel tableLayoutPanel15;
        private TextBox txtbxConfirmPassword;
        private Label lblHomeAddress;
        private Button btnShowPasswrd2;
        private TableLayoutPanel tableLayoutPanel17;
        private RichTextBox rtxtbxHomeAddress;
        private Label lblHomeAddressSignal;
        private TableLayoutPanel tableLayoutPanel14;
        private Button btnClose;
        private Button btnClear;
        private Button btnCreateAccount;
        private TableLayoutPanel tableLayoutPanel16;
        private TableLayoutPanel tableLayoutPanel11;
        private TableLayoutPanel tableLayoutPanel1;
        private GroupBox gbx;
        private TableLayoutPanel tableLayoutPanel2;
        private TableLayoutPanel tableLayoutPanel3;
        private TableLayoutPanel tableLayoutPanel10;
        private Label lblNewPasswordSignal;
        private Label lblEmailAddressSignal;
        private TableLayoutPanel tableLayoutPanel6;
        private TextBox txtbxNewPassowrd;
        private Label lblNewPassword;
        private Button btnShowPassword;
        private Label lblEmailAddress;
        private TextBox txtbxEmailAddress;
        private TableLayoutPanel tableLayoutPanel4;
        private Label lblDesignation;
        private ComboBox cmbxDesignation;
        private Label lblCNIC;
        private TextBox txtbxCNIC;
        private TableLayoutPanel tableLayoutPanel5;
        private Label lblUsername;
        private TextBox txtbxUsername;
        private TextBox txtbxContactNumber;
        private Label lblContactNumber;
        private TableLayoutPanel tableLayoutPanel7;
        private Label lblDesignationSingal;
        private Label lblCNICSignal;
        private TableLayoutPanel tableLayoutPanel8;
        private Label lblGenderSignal;
        private Label lblNameSignal;
        private TableLayoutPanel tableLayoutPanel9;
        private Label lblContactNumberSignal;
        private Label lblUsernameSignal;
    }
}