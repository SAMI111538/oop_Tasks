﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            mainFirstPanel = new TableLayoutPanel();
            sidePanel = new TableLayoutPanel();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            chnageableNewLayout = new TableLayoutPanel();
            mainFirstPanel.SuspendLayout();
            sidePanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // mainFirstPanel
            // 
            mainFirstPanel.ColumnCount = 2;
            mainFirstPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 15.6565657F));
            mainFirstPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 84.34344F));
            mainFirstPanel.Controls.Add(sidePanel, 0, 0);
            mainFirstPanel.Controls.Add(chnageableNewLayout, 1, 0);
            mainFirstPanel.Dock = DockStyle.Fill;
            mainFirstPanel.Location = new Point(0, 0);
            mainFirstPanel.Name = "mainFirstPanel";
            mainFirstPanel.RowCount = 1;
            mainFirstPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            mainFirstPanel.Size = new Size(983, 522);
            mainFirstPanel.TabIndex = 0;
            // 
            // sidePanel
            // 
            sidePanel.ColumnCount = 1;
            sidePanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            sidePanel.Controls.Add(label4, 0, 4);
            sidePanel.Controls.Add(label3, 0, 3);
            sidePanel.Controls.Add(label2, 0, 2);
            sidePanel.Controls.Add(pictureBox1, 0, 0);
            sidePanel.Controls.Add(label1, 0, 1);
            sidePanel.Dock = DockStyle.Left;
            sidePanel.Location = new Point(3, 3);
            sidePanel.Name = "sidePanel";
            sidePanel.RowCount = 5;
            sidePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20.4751873F));
            sidePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20.47519F));
            sidePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20.47519F));
            sidePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 20.47519F));
            sidePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 18.0992489F));
            sidePanel.Size = new Size(147, 516);
            sidePanel.TabIndex = 0;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Dock = DockStyle.Top;
            label4.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(3, 420);
            label4.Name = "label4";
            label4.Size = new Size(141, 21);
            label4.TabIndex = 4;
            label4.Text = " CLICK HERE";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Dock = DockStyle.Top;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(3, 315);
            label3.Name = "label3";
            label3.Size = new Size(141, 21);
            label3.TabIndex = 3;
            label3.Text = " CLICK HERE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Dock = DockStyle.Top;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(3, 210);
            label2.Name = "label2";
            label2.Size = new Size(141, 21);
            label2.TabIndex = 2;
            label2.Text = " CLICK HERE";
            // 
            // pictureBox1
            // 
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = Properties.Resources.logo;
            pictureBox1.Location = new Point(3, 3);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(141, 99);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Dock = DockStyle.Top;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(3, 105);
            label1.Name = "label1";
            label1.Size = new Size(141, 21);
            label1.TabIndex = 1;
            label1.Text = " CLICK HERE";
            label1.Click += label1_Click;
            // 
            // chnageableNewLayout
            // 
            chnageableNewLayout.ColumnCount = 1;
            chnageableNewLayout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            chnageableNewLayout.Dock = DockStyle.Fill;
            chnageableNewLayout.Location = new Point(156, 3);
            chnageableNewLayout.Name = "chnageableNewLayout";
            chnageableNewLayout.RowCount = 1;
            chnageableNewLayout.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            chnageableNewLayout.Size = new Size(824, 516);
            chnageableNewLayout.TabIndex = 1;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(983, 522);
            Controls.Add(mainFirstPanel);
            Name = "Form1";
            Text = "Form1";
            mainFirstPanel.ResumeLayout(false);
            sidePanel.ResumeLayout(false);
            sidePanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private TableLayoutPanel mainFirstPanel;
        private TableLayoutPanel sidePanel;
        private Label label4;
        private Label label3;
        private Label label2;
        private PictureBox pictureBox1;
        private Label label1;
        private TableLayoutPanel chnageableNewLayout;
    }
}