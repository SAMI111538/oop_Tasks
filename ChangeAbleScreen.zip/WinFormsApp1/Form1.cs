﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public void loadc(object usercontrol)
        {

            UserControl f = usercontrol as UserControl;

            f.Dock = DockStyle.Fill;
            this.chnageableNewLayout.Controls.Add(f);

            f.Show();


            // YA FUNCTION MA NY BANYA THA 
         // IS MA YA HO RHA HA KY AIK NEW USER CONTROL TYPE KA OBJECT GET HOTA HA 
         // AUR IS MUTABIK US KO SET KR DYA JATA HA 



        }

        private void label1_Click(object sender, EventArgs e)
        {

            //YA CLICK EVENT HA JAHA WO UPAR WALA FUNCTION CALL HUA 
            // AB DEKHO AIK THA MAIN TABLE LAYOUT
            // AIK AYA SIDE WALA
            // AIK ATA HA CHANGEABLE LAYOUT
            // HUM CHAHTY KY CLIK KRNY PR NEW SCREEEN AJAY 
            // MEANS WO JO CONTROL PANEL BANAYA HA WO SHOW HO JAY 
            // JIS KA NAME THA
            // CHANGE ABLE SCREEN
             
            this.chnageableNewLayout.Controls.Clear();
            // ya ha wo layout jis ma hhum new form/ Control panel kholna chhaty   
            

            loadc(new ChnageAbleScreen());
            // ya wo function call hua ha jis sy wo new control panel khuly ga 
            // ab hum chnageable wali screen pass kr rhy ky wo khuly jo ky ya ha 
        }
    }
}
