﻿
namespace WindowsFormsApp1bc
{
    partial class frmSignIn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSignUpFirstPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblSignUp = new System.Windows.Forms.Label();
            this.lblSignUpSecondPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblNameSignIn = new System.Windows.Forms.Label();
            this.lblPasswordSignIn = new System.Windows.Forms.Label();
            this.txtNameSignIn = new System.Windows.Forms.TextBox();
            this.txtPasswordSignIn = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.LogInButton = new System.Windows.Forms.Button();
            this.linklblSignUp = new System.Windows.Forms.LinkLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblValidationSignInName = new System.Windows.Forms.Label();
            this.lblValidationSignInPass = new System.Windows.Forms.Label();
            this.lblBackSignIn = new System.Windows.Forms.Label();
            this.lblSignUpFirstPannel.SuspendLayout();
            this.lblSignUpSecondPannel.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSignUpFirstPannel
            // 
            this.lblSignUpFirstPannel.BackgroundImage = global::WindowsFormsApp1bc.Properties.Resources.Garments;
            this.lblSignUpFirstPannel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lblSignUpFirstPannel.ColumnCount = 3;
            this.lblSignUpFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.lblSignUpFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.lblSignUpFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.lblSignUpFirstPannel.Controls.Add(this.lblSignUp, 1, 1);
            this.lblSignUpFirstPannel.Controls.Add(this.lblSignUpSecondPannel, 1, 2);
            this.lblSignUpFirstPannel.Controls.Add(this.tableLayoutPanel1, 1, 3);
            this.lblSignUpFirstPannel.Controls.Add(this.tableLayoutPanel2, 2, 2);
            this.lblSignUpFirstPannel.Controls.Add(this.lblBackSignIn, 1, 4);
            this.lblSignUpFirstPannel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSignUpFirstPannel.Location = new System.Drawing.Point(0, 0);
            this.lblSignUpFirstPannel.Name = "lblSignUpFirstPannel";
            this.lblSignUpFirstPannel.RowCount = 6;
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.Size = new System.Drawing.Size(1447, 784);
            this.lblSignUpFirstPannel.TabIndex = 2;
            // 
            // lblSignUp
            // 
            this.lblSignUp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSignUp.AutoSize = true;
            this.lblSignUp.Font = new System.Drawing.Font("Algerian", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSignUp.Location = new System.Drawing.Point(590, 174);
            this.lblSignUp.Name = "lblSignUp";
            this.lblSignUp.Size = new System.Drawing.Size(265, 42);
            this.lblSignUp.TabIndex = 0;
            this.lblSignUp.Text = "Sign In Menu";
            // 
            // lblSignUpSecondPannel
            // 
            this.lblSignUpSecondPannel.BackColor = System.Drawing.Color.Transparent;
            this.lblSignUpSecondPannel.ColumnCount = 2;
            this.lblSignUpSecondPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 157F));
            this.lblSignUpSecondPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.lblSignUpSecondPannel.Controls.Add(this.lblNameSignIn, 0, 0);
            this.lblSignUpSecondPannel.Controls.Add(this.lblPasswordSignIn, 0, 1);
            this.lblSignUpSecondPannel.Controls.Add(this.txtNameSignIn, 1, 0);
            this.lblSignUpSecondPannel.Controls.Add(this.txtPasswordSignIn, 1, 1);
            this.lblSignUpSecondPannel.Location = new System.Drawing.Point(485, 263);
            this.lblSignUpSecondPannel.Name = "lblSignUpSecondPannel";
            this.lblSignUpSecondPannel.RowCount = 2;
            this.lblSignUpSecondPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.lblSignUpSecondPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.lblSignUpSecondPannel.Size = new System.Drawing.Size(476, 117);
            this.lblSignUpSecondPannel.TabIndex = 1;
            // 
            // lblNameSignIn
            // 
            this.lblNameSignIn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblNameSignIn.AutoSize = true;
            this.lblNameSignIn.Font = new System.Drawing.Font("Algerian", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNameSignIn.Location = new System.Drawing.Point(40, 16);
            this.lblNameSignIn.Name = "lblNameSignIn";
            this.lblNameSignIn.Size = new System.Drawing.Size(76, 25);
            this.lblNameSignIn.TabIndex = 0;
            this.lblNameSignIn.Text = "NAME";
            // 
            // lblPasswordSignIn
            // 
            this.lblPasswordSignIn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPasswordSignIn.AutoSize = true;
            this.lblPasswordSignIn.Font = new System.Drawing.Font("Algerian", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPasswordSignIn.Location = new System.Drawing.Point(12, 75);
            this.lblPasswordSignIn.Name = "lblPasswordSignIn";
            this.lblPasswordSignIn.Size = new System.Drawing.Size(132, 25);
            this.lblPasswordSignIn.TabIndex = 1;
            this.lblPasswordSignIn.Text = "Password";
            // 
            // txtNameSignIn
            // 
            this.txtNameSignIn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNameSignIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameSignIn.Location = new System.Drawing.Point(160, 10);
            this.txtNameSignIn.Name = "txtNameSignIn";
            this.txtNameSignIn.Size = new System.Drawing.Size(313, 38);
            this.txtNameSignIn.TabIndex = 2;
            this.txtNameSignIn.TextChanged += new System.EventHandler(this.txtNameSignIn_TextChanged);
            // 
            // txtPasswordSignIn
            // 
            this.txtPasswordSignIn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPasswordSignIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordSignIn.Location = new System.Drawing.Point(160, 68);
            this.txtPasswordSignIn.Name = "txtPasswordSignIn";
            this.txtPasswordSignIn.PasswordChar = '*';
            this.txtPasswordSignIn.Size = new System.Drawing.Size(313, 38);
            this.txtPasswordSignIn.TabIndex = 2;
            this.txtPasswordSignIn.TextChanged += new System.EventHandler(this.txtPasswordSignIn_TextChanged);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.LogInButton, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.linklblSignUp, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(485, 393);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(476, 120);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // LogInButton
            // 
            this.LogInButton.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.LogInButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogInButton.Location = new System.Drawing.Point(354, 3);
            this.LogInButton.Name = "LogInButton";
            this.LogInButton.Size = new System.Drawing.Size(119, 44);
            this.LogInButton.TabIndex = 4;
            this.LogInButton.Text = "LogIn";
            this.LogInButton.UseVisualStyleBackColor = true;
            this.LogInButton.Click += new System.EventHandler(this.LogInButton_Click);
            // 
            // linklblSignUp
            // 
            this.linklblSignUp.AutoSize = true;
            this.linklblSignUp.BackColor = System.Drawing.Color.Transparent;
            this.linklblSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblSignUp.Location = new System.Drawing.Point(3, 0);
            this.linklblSignUp.Name = "linklblSignUp";
            this.linklblSignUp.Size = new System.Drawing.Size(176, 29);
            this.linklblSignUp.TabIndex = 2;
            this.linklblSignUp.TabStop = true;
            this.linklblSignUp.Text = "Create Account";
            this.linklblSignUp.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklblSignUp_LinkClicked);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.lblValidationSignInName, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblValidationSignInPass, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(967, 263);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(276, 124);
            this.tableLayoutPanel2.TabIndex = 6;
            // 
            // lblValidationSignInName
            // 
            this.lblValidationSignInName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationSignInName.AutoSize = true;
            this.lblValidationSignInName.BackColor = System.Drawing.Color.Transparent;
            this.lblValidationSignInName.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationSignInName.Location = new System.Drawing.Point(3, 18);
            this.lblValidationSignInName.Name = "lblValidationSignInName";
            this.lblValidationSignInName.Size = new System.Drawing.Size(0, 26);
            this.lblValidationSignInName.TabIndex = 0;
            // 
            // lblValidationSignInPass
            // 
            this.lblValidationSignInPass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationSignInPass.AutoSize = true;
            this.lblValidationSignInPass.BackColor = System.Drawing.Color.Transparent;
            this.lblValidationSignInPass.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationSignInPass.Location = new System.Drawing.Point(3, 80);
            this.lblValidationSignInPass.Name = "lblValidationSignInPass";
            this.lblValidationSignInPass.Size = new System.Drawing.Size(0, 26);
            this.lblValidationSignInPass.TabIndex = 0;
            // 
            // lblBackSignIn
            // 
            this.lblBackSignIn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblBackSignIn.AutoSize = true;
            this.lblBackSignIn.BackColor = System.Drawing.Color.Transparent;
            this.lblBackSignIn.Font = new System.Drawing.Font("Algerian", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBackSignIn.ForeColor = System.Drawing.Color.Red;
            this.lblBackSignIn.Location = new System.Drawing.Point(653, 560);
            this.lblBackSignIn.Name = "lblBackSignIn";
            this.lblBackSignIn.Size = new System.Drawing.Size(139, 49);
            this.lblBackSignIn.TabIndex = 7;
            this.lblBackSignIn.Text = "Back";
            this.lblBackSignIn.Click += new System.EventHandler(this.lblBackSignIn_Click);
            // 
            // frmSignIn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1447, 784);
            this.Controls.Add(this.lblSignUpFirstPannel);
            this.Name = "frmSignIn";
            this.Text = "Sign In";
            this.lblSignUpFirstPannel.ResumeLayout(false);
            this.lblSignUpFirstPannel.PerformLayout();
            this.lblSignUpSecondPannel.ResumeLayout(false);
            this.lblSignUpSecondPannel.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel lblSignUpFirstPannel;
        private System.Windows.Forms.Label lblSignUp;
        private System.Windows.Forms.TableLayoutPanel lblSignUpSecondPannel;
        private System.Windows.Forms.Label lblNameSignIn;
        private System.Windows.Forms.Label lblPasswordSignIn;
        private System.Windows.Forms.TextBox txtNameSignIn;
        private System.Windows.Forms.TextBox txtPasswordSignIn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button LogInButton;
        private System.Windows.Forms.LinkLabel linklblSignUp;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblValidationSignInName;
        private System.Windows.Forms.Label lblValidationSignInPass;
        private System.Windows.Forms.Label lblBackSignIn;
    }
}