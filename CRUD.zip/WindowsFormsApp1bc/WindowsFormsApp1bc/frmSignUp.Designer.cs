﻿
namespace WindowsFormsApp1bc
{
    partial class frmSignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSignUpFirstPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblSignUp = new System.Windows.Forms.Label();
            this.lblSignUpSecondPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblName = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.txtNameSignUp = new System.Windows.Forms.TextBox();
            this.txtPasswordSignUp = new System.Windows.Forms.TextBox();
            this.tblThirdSignUpPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblRole = new System.Windows.Forms.Label();
            this.txtRoleSignUp = new System.Windows.Forms.TextBox();
            this.SignUp_Button = new System.Windows.Forms.Button();
            this.linklblforSignIn = new System.Windows.Forms.LinkLabel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblValidationSignUpName = new System.Windows.Forms.Label();
            this.lblValidationSignUpPass = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblValidationSignUpRole = new System.Windows.Forms.Label();
            this.lblBackSignUp = new System.Windows.Forms.Label();
            this.lblSignUpFirstPannel.SuspendLayout();
            this.lblSignUpSecondPannel.SuspendLayout();
            this.tblThirdSignUpPannel.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSignUpFirstPannel
            // 
            this.lblSignUpFirstPannel.BackgroundImage = global::WindowsFormsApp1bc.Properties.Resources.Garments;
            this.lblSignUpFirstPannel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.lblSignUpFirstPannel.ColumnCount = 3;
            this.lblSignUpFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.lblSignUpFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.lblSignUpFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.lblSignUpFirstPannel.Controls.Add(this.lblBackSignUp, 1, 5);
            this.lblSignUpFirstPannel.Controls.Add(this.lblSignUp, 1, 1);
            this.lblSignUpFirstPannel.Controls.Add(this.lblSignUpSecondPannel, 1, 2);
            this.lblSignUpFirstPannel.Controls.Add(this.tblThirdSignUpPannel, 1, 3);
            this.lblSignUpFirstPannel.Controls.Add(this.linklblforSignIn, 1, 4);
            this.lblSignUpFirstPannel.Controls.Add(this.tableLayoutPanel2, 2, 2);
            this.lblSignUpFirstPannel.Controls.Add(this.tableLayoutPanel1, 2, 3);
            this.lblSignUpFirstPannel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lblSignUpFirstPannel.Location = new System.Drawing.Point(0, 0);
            this.lblSignUpFirstPannel.Name = "lblSignUpFirstPannel";
            this.lblSignUpFirstPannel.RowCount = 6;
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.lblSignUpFirstPannel.Size = new System.Drawing.Size(1486, 743);
            this.lblSignUpFirstPannel.TabIndex = 1;
            // 
            // lblSignUp
            // 
            this.lblSignUp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSignUp.AutoSize = true;
            this.lblSignUp.Font = new System.Drawing.Font("Algerian", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSignUp.Location = new System.Drawing.Point(605, 163);
            this.lblSignUp.Name = "lblSignUp";
            this.lblSignUp.Size = new System.Drawing.Size(275, 42);
            this.lblSignUp.TabIndex = 0;
            this.lblSignUp.Text = "Sign Up Menu";
            // 
            // lblSignUpSecondPannel
            // 
            this.lblSignUpSecondPannel.BackColor = System.Drawing.Color.Transparent;
            this.lblSignUpSecondPannel.ColumnCount = 2;
            this.lblSignUpSecondPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 157F));
            this.lblSignUpSecondPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.lblSignUpSecondPannel.Controls.Add(this.lblName, 0, 0);
            this.lblSignUpSecondPannel.Controls.Add(this.lblPassword, 0, 1);
            this.lblSignUpSecondPannel.Controls.Add(this.txtNameSignUp, 1, 0);
            this.lblSignUpSecondPannel.Controls.Add(this.txtPasswordSignUp, 1, 1);
            this.lblSignUpSecondPannel.Location = new System.Drawing.Point(498, 249);
            this.lblSignUpSecondPannel.Name = "lblSignUpSecondPannel";
            this.lblSignUpSecondPannel.RowCount = 2;
            this.lblSignUpSecondPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.lblSignUpSecondPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.lblSignUpSecondPannel.Size = new System.Drawing.Size(489, 117);
            this.lblSignUpSecondPannel.TabIndex = 1;
            // 
            // lblName
            // 
            this.lblName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblName.AutoSize = true;
            this.lblName.Font = new System.Drawing.Font("Algerian", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblName.Location = new System.Drawing.Point(40, 16);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(76, 25);
            this.lblName.TabIndex = 0;
            this.lblName.Text = "NAME";
            // 
            // lblPassword
            // 
            this.lblPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPassword.AutoSize = true;
            this.lblPassword.Font = new System.Drawing.Font("Algerian", 13.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPassword.Location = new System.Drawing.Point(12, 75);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(132, 25);
            this.lblPassword.TabIndex = 1;
            this.lblPassword.Text = "Password";
            // 
            // txtNameSignUp
            // 
            this.txtNameSignUp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtNameSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNameSignUp.Location = new System.Drawing.Point(160, 10);
            this.txtNameSignUp.Name = "txtNameSignUp";
            this.txtNameSignUp.Size = new System.Drawing.Size(326, 38);
            this.txtNameSignUp.TabIndex = 2;
            this.txtNameSignUp.TextChanged += new System.EventHandler(this.txtNameSignUp_TextChanged);
            // 
            // txtPasswordSignUp
            // 
            this.txtPasswordSignUp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtPasswordSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPasswordSignUp.Location = new System.Drawing.Point(160, 68);
            this.txtPasswordSignUp.Name = "txtPasswordSignUp";
            this.txtPasswordSignUp.PasswordChar = '*';
            this.txtPasswordSignUp.Size = new System.Drawing.Size(326, 38);
            this.txtPasswordSignUp.TabIndex = 2;
            this.txtPasswordSignUp.TextChanged += new System.EventHandler(this.txtPasswordSignUp_TextChanged);
            // 
            // tblThirdSignUpPannel
            // 
            this.tblThirdSignUpPannel.BackColor = System.Drawing.Color.Transparent;
            this.tblThirdSignUpPannel.ColumnCount = 2;
            this.tblThirdSignUpPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 157F));
            this.tblThirdSignUpPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblThirdSignUpPannel.Controls.Add(this.lblRole, 0, 0);
            this.tblThirdSignUpPannel.Controls.Add(this.txtRoleSignUp, 1, 0);
            this.tblThirdSignUpPannel.Controls.Add(this.SignUp_Button, 1, 1);
            this.tblThirdSignUpPannel.Location = new System.Drawing.Point(498, 372);
            this.tblThirdSignUpPannel.Name = "tblThirdSignUpPannel";
            this.tblThirdSignUpPannel.RowCount = 2;
            this.tblThirdSignUpPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblThirdSignUpPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblThirdSignUpPannel.Size = new System.Drawing.Size(489, 117);
            this.tblThirdSignUpPannel.TabIndex = 2;
            // 
            // lblRole
            // 
            this.lblRole.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblRole.AutoSize = true;
            this.lblRole.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRole.Location = new System.Drawing.Point(41, 16);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(74, 26);
            this.lblRole.TabIndex = 0;
            this.lblRole.Text = "Role";
            // 
            // txtRoleSignUp
            // 
            this.txtRoleSignUp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtRoleSignUp.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRoleSignUp.Location = new System.Drawing.Point(160, 10);
            this.txtRoleSignUp.Name = "txtRoleSignUp";
            this.txtRoleSignUp.Size = new System.Drawing.Size(326, 38);
            this.txtRoleSignUp.TabIndex = 2;
            this.txtRoleSignUp.TextChanged += new System.EventHandler(this.txtRoleSignUp_TextChanged);
            // 
            // SignUp_Button
            // 
            this.SignUp_Button.BackColor = System.Drawing.Color.DimGray;
            this.SignUp_Button.Dock = System.Windows.Forms.DockStyle.Right;
            this.SignUp_Button.Location = new System.Drawing.Point(357, 61);
            this.SignUp_Button.Name = "SignUp_Button";
            this.SignUp_Button.Size = new System.Drawing.Size(129, 53);
            this.SignUp_Button.TabIndex = 3;
            this.SignUp_Button.Text = "Register";
            this.SignUp_Button.UseVisualStyleBackColor = false;
            this.SignUp_Button.Click += new System.EventHandler(this.button1_Click);
            // 
            // linklblforSignIn
            // 
            this.linklblforSignIn.AutoSize = true;
            this.linklblforSignIn.BackColor = System.Drawing.Color.Transparent;
            this.linklblforSignIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblforSignIn.Location = new System.Drawing.Point(498, 492);
            this.linklblforSignIn.Name = "linklblforSignIn";
            this.linklblforSignIn.Size = new System.Drawing.Size(279, 25);
            this.linklblforSignIn.TabIndex = 4;
            this.linklblforSignIn.TabStop = true;
            this.linklblforSignIn.Text = "Already has an Account?Login";
            this.linklblforSignIn.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklblforSignIn_LinkClicked);
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.lblValidationSignUpName, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblValidationSignUpPass, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(993, 249);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(276, 117);
            this.tableLayoutPanel2.TabIndex = 7;
            // 
            // lblValidationSignUpName
            // 
            this.lblValidationSignUpName.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationSignUpName.AutoSize = true;
            this.lblValidationSignUpName.BackColor = System.Drawing.Color.Transparent;
            this.lblValidationSignUpName.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationSignUpName.Location = new System.Drawing.Point(3, 16);
            this.lblValidationSignUpName.Name = "lblValidationSignUpName";
            this.lblValidationSignUpName.Size = new System.Drawing.Size(0, 26);
            this.lblValidationSignUpName.TabIndex = 0;
            // 
            // lblValidationSignUpPass
            // 
            this.lblValidationSignUpPass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationSignUpPass.AutoSize = true;
            this.lblValidationSignUpPass.BackColor = System.Drawing.Color.Transparent;
            this.lblValidationSignUpPass.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationSignUpPass.Location = new System.Drawing.Point(3, 74);
            this.lblValidationSignUpPass.Name = "lblValidationSignUpPass";
            this.lblValidationSignUpPass.Size = new System.Drawing.Size(0, 26);
            this.lblValidationSignUpPass.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.Color.Transparent;
            this.tableLayoutPanel1.ColumnCount = 1;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lblValidationSignUpRole, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(993, 372);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(267, 114);
            this.tableLayoutPanel1.TabIndex = 8;
            // 
            // lblValidationSignUpRole
            // 
            this.lblValidationSignUpRole.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationSignUpRole.AutoSize = true;
            this.lblValidationSignUpRole.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationSignUpRole.Location = new System.Drawing.Point(3, 13);
            this.lblValidationSignUpRole.Name = "lblValidationSignUpRole";
            this.lblValidationSignUpRole.Size = new System.Drawing.Size(0, 31);
            this.lblValidationSignUpRole.TabIndex = 0;
            // 
            // lblBackSignUp
            // 
            this.lblBackSignUp.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblBackSignUp.AutoSize = true;
            this.lblBackSignUp.BackColor = System.Drawing.Color.Transparent;
            this.lblBackSignUp.Font = new System.Drawing.Font("Algerian", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBackSignUp.ForeColor = System.Drawing.Color.Red;
            this.lblBackSignUp.Location = new System.Drawing.Point(673, 654);
            this.lblBackSignUp.Name = "lblBackSignUp";
            this.lblBackSignUp.Size = new System.Drawing.Size(139, 49);
            this.lblBackSignUp.TabIndex = 8;
            this.lblBackSignUp.Text = "Back";
            this.lblBackSignUp.Click += new System.EventHandler(this.lblBackSignUp_Click);
            // 
            // frmSignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1486, 743);
            this.Controls.Add(this.lblSignUpFirstPannel);
            this.Name = "frmSignUp";
            this.Text = "Sign Up";
            this.lblSignUpFirstPannel.ResumeLayout(false);
            this.lblSignUpFirstPannel.PerformLayout();
            this.lblSignUpSecondPannel.ResumeLayout(false);
            this.lblSignUpSecondPannel.PerformLayout();
            this.tblThirdSignUpPannel.ResumeLayout(false);
            this.tblThirdSignUpPannel.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel lblSignUpFirstPannel;
        private System.Windows.Forms.Label lblSignUp;
        private System.Windows.Forms.TableLayoutPanel lblSignUpSecondPannel;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.TextBox txtNameSignUp;
        private System.Windows.Forms.TextBox txtPasswordSignUp;
        private System.Windows.Forms.TableLayoutPanel tblThirdSignUpPannel;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.TextBox txtRoleSignUp;
        private System.Windows.Forms.Button SignUp_Button;
        private System.Windows.Forms.LinkLabel linklblforSignIn;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblValidationSignUpName;
        private System.Windows.Forms.Label lblValidationSignUpPass;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblValidationSignUpRole;
        private System.Windows.Forms.Label lblBackSignUp;
    }
}