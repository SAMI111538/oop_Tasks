﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    public partial class UC_CustomerChangePassword : UserControl
    {
        Customer customer;
        bool Check;
        public UC_CustomerChangePassword(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
        }

        private void btnCusChangePassword_Click(object sender, EventArgs e)
        {
            if (txtOldCusPassword.Text != string.Empty)
            {
                if (txtOldCusPassword.Text == customer.getPassword())
                {
                    if (txtCusNewPassword.Text != txtOldCusPassword.Text) // Check if new password is different from the old password
                    {
                        if (txtCusNewPassword.Text == txtCusConfirmPassword.Text)
                        {
                            if (IsPasswordValid(txtCusNewPassword.Text))
                            {
                                customer.setPassword(txtCusNewPassword.Text);
                                MUserDL.storeDataInFile();
                                MessageBox.Show("Password changed successfully");
                            }
                            else
                            {
                                MessageBox.Show("Invalid new password format. Password must be 8 characters long and contain at least one special character, one numeric character, and alphabetic characters.");
                            }
                        }
                        else
                        {
                            MessageBox.Show("New password and confirm password do not match.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("New password must be different from the old password.");
                    }
                }
                else
                {
                    MessageBox.Show("Please input correct old password.");
                }
            }
            else
            {
                MessageBox.Show("Please enter something in the old password field.");
            }
        }

        private void txtOldCusPassword_TextChanged(object sender, EventArgs e)
        {
            Check = IsPasswordValid(txtOldCusPassword.Text);
            if (Check == true)
            {
                lblValidationCusOldPass.ForeColor = Color.Green;
                lblValidationCusOldPass.Text = "Valid";
            }
            else
            {
                lblValidationCusOldPass.ForeColor = Color.Red;
                lblValidationCusOldPass.Text = "Password 8 Character & Digits & Special Charcter";
            }
        }

        private void txtCusNewPassword_TextChanged(object sender, EventArgs e)
        {
            Check = IsPasswordValid(txtCusNewPassword.Text);
            if (Check == true)
            {
                lblValidationCusNewPass.ForeColor = Color.Green;
                lblValidationCusNewPass.Text = "Valid";
            }
            else
            {
                lblValidationCusNewPass.ForeColor = Color.Red;
                lblValidationCusNewPass.Text = "Password 8 Character & Digits & Special Charcter";
            }
        }

        private void txtCusConfirmPassword_TextChanged(object sender, EventArgs e)
        {
            Check = IsPasswordValid(txtCusConfirmPassword.Text);
            if (Check == true)
            {
                lblValidationCusConfirmPass.ForeColor = Color.Green;
                lblValidationCusConfirmPass.Text = "Valid";
            }
            else
            {
                lblValidationCusConfirmPass.ForeColor = Color.Red;
                lblValidationCusConfirmPass.Text = "Password 8 Character & Digits & Special Charcter";
            }
        }

        static bool IsPasswordValid(string password)
        {
            // Check if the password length is at least 8 characters
            if (password.Length < 8)
            {
                return false;
            }

            // Check if the password contains at least one special character and one number
            bool containsSpecialChar = false;
            bool containsNumber = false;

            foreach (char c in password)
            {
                if (char.IsDigit(c))
                {
                    containsNumber = true;
                }
                else if (char.IsSymbol(c) || char.IsPunctuation(c))
                {
                    containsSpecialChar = true;
                }

                // If both conditions are met, no need to check further
                if (containsNumber && containsSpecialChar)
                {
                    break;
                }
            }

            // Return true if both conditions are met (valid password), otherwise false
            return containsNumber && containsSpecialChar;
        }
    }
}
