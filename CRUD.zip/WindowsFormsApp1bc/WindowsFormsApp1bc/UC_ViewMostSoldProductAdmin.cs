﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    public partial class UC_ViewMostSoldProductAdmin : UserControl
    {
        Admin admin;
        public UC_ViewMostSoldProductAdmin(Admin admin)
        {
            InitializeComponent();
            this.admin = admin;
        }

        private void btn_MostSoldProductAdminBack_Click(object sender, EventArgs e)
        {
            Hide();
            frmAdminMainMenu obj = new frmAdminMainMenu(admin);
            obj.ShowDialog();
        }
        private void UC_ViewMostSoldProductAdmin_Load(object sender, EventArgs e)
        {
            pro_duct pro = PDataLayer.sortBySoldedItem();
            lblSoldName.Text += pro.Pro_Name;
            lblSoldQuantity.Text += pro.Most_sold;
        }
    }
}
