﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;

namespace WindowsFormsApp1bc
{
    public partial class frmCustomerMainMenu : Form
    {
        Customer customer;
        public frmCustomerMainMenu(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
        }

      

        private void loadforms(UC_AddInfo frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblAddInfo_Click(object sender, EventArgs e)
        {
            loadforms(new UC_AddInfo(customer));
        }

        private void lblViewProductCustomer_Click(object sender, EventArgs e)
        {
            loadforms(new UC_ViewProductCustomer());
        }

        private void loadforms(UC_ViewProductCustomer frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblAddToCart_Click(object sender, EventArgs e)
        {
            loadforms(new UC_AddToCart(customer));
        }

        private void loadforms(UC_AddToCart frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        
        
        private void loadforms(UC_AddFeedBack frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblGiveFeedback_Click(object sender, EventArgs e)
        {
            loadforms(new UC_AddFeedBack(customer));
        }

        private void lblViewBill_Click(object sender, EventArgs e)
        {
            loadforms(new UC_BillCalculate(customer));
        }
        private void loadforms(UC_BillCalculate frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void loadforms(UC_ViewMostPopularProductCustomer frm)
        {  
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblChangePasswordCustomer_Click(object sender, EventArgs e)
        {
            loadforms(new UC_CustomerChangePassword(customer));
        }


        private void loadforms(UC_CustomerChangePassword frm)
        {
            try
            {
                this.screenpanel.Controls.Clear();
                UserControl f = frm as UserControl;

                f.Dock = DockStyle.Fill;
                this.screenpanel.Controls.Add(f);
                this.screenpanel.Tag = f;
                f.Show();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void lblPopularProduct_Click(object sender, EventArgs e)
        {
            loadforms(new UC_ViewMostPopularProductCustomer(customer));
        }

        private void lblExitCus_Click(object sender, EventArgs e)
        {
            Hide();
            frmSignIn obj = new frmSignIn();
            obj.ShowDialog();
        }


    }
}
