﻿
namespace WindowsFormsApp1bc
{
    partial class frmAdminMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tblAdminLeftPannel = new System.Windows.Forms.TableLayoutPanel();
            this.lblAddProduct = new System.Windows.Forms.Label();
            this.pbAdminMenu_Logo = new System.Windows.Forms.PictureBox();
            this.lblViewProduct = new System.Windows.Forms.Label();
            this.lblSorting = new System.Windows.Forms.Label();
            this.lblChangePassword = new System.Windows.Forms.Label();
            this.lblMostSoldProduct = new System.Windows.Forms.Label();
            this.lblFeedbackView = new System.Windows.Forms.Label();
            this.lblExitAdmin = new System.Windows.Forms.Label();
            this.tblAdminFirstPannel = new System.Windows.Forms.TableLayoutPanel();
            this.screenpanel = new System.Windows.Forms.TableLayoutPanel();
            this.tblAdminLeftPannel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAdminMenu_Logo)).BeginInit();
            this.tblAdminFirstPannel.SuspendLayout();
            this.SuspendLayout();
            // 
            // tblAdminLeftPannel
            // 
            this.tblAdminLeftPannel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblAdminLeftPannel.ColumnCount = 1;
            this.tblAdminLeftPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tblAdminLeftPannel.Controls.Add(this.lblAddProduct, 0, 1);
            this.tblAdminLeftPannel.Controls.Add(this.pbAdminMenu_Logo, 0, 0);
            this.tblAdminLeftPannel.Controls.Add(this.lblViewProduct, 0, 2);
            this.tblAdminLeftPannel.Controls.Add(this.lblSorting, 0, 3);
            this.tblAdminLeftPannel.Controls.Add(this.lblChangePassword, 0, 4);
            this.tblAdminLeftPannel.Controls.Add(this.lblMostSoldProduct, 0, 5);
            this.tblAdminLeftPannel.Controls.Add(this.lblFeedbackView, 0, 6);
            this.tblAdminLeftPannel.Controls.Add(this.lblExitAdmin, 0, 7);
            this.tblAdminLeftPannel.Dock = System.Windows.Forms.DockStyle.Left;
            this.tblAdminLeftPannel.Location = new System.Drawing.Point(3, 3);
            this.tblAdminLeftPannel.Name = "tblAdminLeftPannel";
            this.tblAdminLeftPannel.RowCount = 8;
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 22.55119F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.744882F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.744882F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.744882F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.744882F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.744882F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.744882F));
            this.tblAdminLeftPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 7.744882F));
            this.tblAdminLeftPannel.Size = new System.Drawing.Size(257, 748);
            this.tblAdminLeftPannel.TabIndex = 0;
            // 
            // lblAddProduct
            // 
            this.lblAddProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblAddProduct.AutoSize = true;
            this.lblAddProduct.Font = new System.Drawing.Font("Algerian", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAddProduct.Location = new System.Drawing.Point(40, 243);
            this.lblAddProduct.Name = "lblAddProduct";
            this.lblAddProduct.Size = new System.Drawing.Size(176, 26);
            this.lblAddProduct.TabIndex = 0;
            this.lblAddProduct.Text = "ADD PRODUCT";
            this.lblAddProduct.Click += new System.EventHandler(this.lblAddProduct_Click);
            // 
            // pbAdminMenu_Logo
            // 
            this.pbAdminMenu_Logo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pbAdminMenu_Logo.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pbAdminMenu_Logo.Image = global::WindowsFormsApp1bc.Properties.Resources.M1_removebg_preview;
            this.pbAdminMenu_Logo.Location = new System.Drawing.Point(3, 3);
            this.pbAdminMenu_Logo.Name = "pbAdminMenu_Logo";
            this.pbAdminMenu_Logo.Size = new System.Drawing.Size(251, 213);
            this.pbAdminMenu_Logo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbAdminMenu_Logo.TabIndex = 1;
            this.pbAdminMenu_Logo.TabStop = false;
            // 
            // lblViewProduct
            // 
            this.lblViewProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblViewProduct.AutoSize = true;
            this.lblViewProduct.Font = new System.Drawing.Font("Algerian", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblViewProduct.Location = new System.Drawing.Point(35, 318);
            this.lblViewProduct.Name = "lblViewProduct";
            this.lblViewProduct.Size = new System.Drawing.Size(187, 26);
            this.lblViewProduct.TabIndex = 1;
            this.lblViewProduct.Text = "VIEW PRODUCT";
            this.lblViewProduct.Click += new System.EventHandler(this.lblViewProduct_Click);
            // 
            // lblSorting
            // 
            this.lblSorting.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblSorting.AutoSize = true;
            this.lblSorting.Font = new System.Drawing.Font("Algerian", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSorting.Location = new System.Drawing.Point(72, 393);
            this.lblSorting.Name = "lblSorting";
            this.lblSorting.Size = new System.Drawing.Size(113, 26);
            this.lblSorting.TabIndex = 1;
            this.lblSorting.Text = "SORTING";
            this.lblSorting.Click += new System.EventHandler(this.lblSorting_Click);
            // 
            // lblChangePassword
            // 
            this.lblChangePassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblChangePassword.AutoSize = true;
            this.lblChangePassword.Font = new System.Drawing.Font("Algerian", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblChangePassword.Location = new System.Drawing.Point(5, 468);
            this.lblChangePassword.Name = "lblChangePassword";
            this.lblChangePassword.Size = new System.Drawing.Size(246, 26);
            this.lblChangePassword.TabIndex = 1;
            this.lblChangePassword.Text = "CHANGE PASSWORD";
            this.lblChangePassword.Click += new System.EventHandler(this.lblChangePassword_Click);
            // 
            // lblMostSoldProduct
            // 
            this.lblMostSoldProduct.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMostSoldProduct.AutoSize = true;
            this.lblMostSoldProduct.Font = new System.Drawing.Font("Algerian", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostSoldProduct.Location = new System.Drawing.Point(16, 543);
            this.lblMostSoldProduct.Name = "lblMostSoldProduct";
            this.lblMostSoldProduct.Size = new System.Drawing.Size(225, 26);
            this.lblMostSoldProduct.TabIndex = 1;
            this.lblMostSoldProduct.Text = "FAMOUS PRODUCT";
            this.lblMostSoldProduct.Click += new System.EventHandler(this.lblMostSoldProduct_Click);
            // 
            // lblFeedbackView
            // 
            this.lblFeedbackView.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblFeedbackView.AutoSize = true;
            this.lblFeedbackView.Font = new System.Drawing.Font("Algerian", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFeedbackView.Location = new System.Drawing.Point(24, 618);
            this.lblFeedbackView.Name = "lblFeedbackView";
            this.lblFeedbackView.Size = new System.Drawing.Size(208, 26);
            this.lblFeedbackView.TabIndex = 1;
            this.lblFeedbackView.Text = "VIEW FEEDBACK";
            this.lblFeedbackView.Click += new System.EventHandler(this.lblFeedbackView_Click);
            // 
            // lblExitAdmin
            // 
            this.lblExitAdmin.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblExitAdmin.AutoSize = true;
            this.lblExitAdmin.Font = new System.Drawing.Font("Algerian", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExitAdmin.Location = new System.Drawing.Point(94, 695);
            this.lblExitAdmin.Name = "lblExitAdmin";
            this.lblExitAdmin.Size = new System.Drawing.Size(69, 26);
            this.lblExitAdmin.TabIndex = 1;
            this.lblExitAdmin.Text = "EXIT";
            this.lblExitAdmin.Click += new System.EventHandler(this.lblExitAdmin_Click);
            // 
            // tblAdminFirstPannel
            // 
            this.tblAdminFirstPannel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblAdminFirstPannel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tblAdminFirstPannel.ColumnCount = 2;
            this.tblAdminFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 17.78368F));
            this.tblAdminFirstPannel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 82.21632F));
            this.tblAdminFirstPannel.Controls.Add(this.tblAdminLeftPannel, 0, 0);
            this.tblAdminFirstPannel.Controls.Add(this.screenpanel, 1, 0);
            this.tblAdminFirstPannel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblAdminFirstPannel.Location = new System.Drawing.Point(0, 0);
            this.tblAdminFirstPannel.Name = "tblAdminFirstPannel";
            this.tblAdminFirstPannel.RowCount = 1;
            this.tblAdminFirstPannel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblAdminFirstPannel.Size = new System.Drawing.Size(1479, 754);
            this.tblAdminFirstPannel.TabIndex = 1;
            // 
            // screenpanel
            // 
            this.screenpanel.BackgroundImage = global::WindowsFormsApp1bc.Properties.Resources.Garmentt1;
            this.screenpanel.ColumnCount = 1;
            this.screenpanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.screenpanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.screenpanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.screenpanel.Location = new System.Drawing.Point(266, 3);
            this.screenpanel.Name = "screenpanel";
            this.screenpanel.RowCount = 1;
            this.screenpanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.screenpanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 748F));
            this.screenpanel.Size = new System.Drawing.Size(1210, 748);
            this.screenpanel.TabIndex = 1;
            // 
            // frmAdminMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1479, 754);
            this.Controls.Add(this.tblAdminFirstPannel);
            this.Name = "frmAdminMainMenu";
            this.Text = "Admin Main Menu";
            this.tblAdminLeftPannel.ResumeLayout(false);
            this.tblAdminLeftPannel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbAdminMenu_Logo)).EndInit();
            this.tblAdminFirstPannel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tblAdminLeftPannel;
        private System.Windows.Forms.Label lblAddProduct;
        private System.Windows.Forms.PictureBox pbAdminMenu_Logo;
        private System.Windows.Forms.Label lblViewProduct;
        private System.Windows.Forms.Label lblSorting;
        private System.Windows.Forms.Label lblMostSoldProduct;
        private System.Windows.Forms.Label lblChangePassword;
        private System.Windows.Forms.Label lblFeedbackView;
        private System.Windows.Forms.TableLayoutPanel screenpanel;
        private System.Windows.Forms.TableLayoutPanel tblAdminFirstPannel;
        private System.Windows.Forms.Label lblExitAdmin;
    }
}