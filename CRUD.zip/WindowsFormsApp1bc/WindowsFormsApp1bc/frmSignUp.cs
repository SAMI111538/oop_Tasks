﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.DL;
using WindowsFormsApp1bc.BL;

namespace WindowsFormsApp1bc
{
    public partial class frmSignUp : Form
    {
        bool check;
        public frmSignUp()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MUser signUp_User = TakeInputWithRoleSignUp();

            if (signUp_User != null)
            {
                if (IsPasswordValid(signUp_User.getPassword()))
                {
                    DataDL.SetSignUpObject(signUp_User);
                    MUserDL.storeDataInList(signUp_User);

                    if (signUp_User.getRole().Equals("customer", StringComparison.OrdinalIgnoreCase))
                    {
                        CustomerDL.addCustomerInList(new Customer(signUp_User.getName(), signUp_User.getPassword(), signUp_User.getRole()));
                    }

                    MUserDL.storeDataInFile(DataDL.GetUsersPath(), signUp_User);

                    MessageBox.Show("SignedUp Successfully");

                    frmSignIn form = new frmSignIn();
                    form.Show();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Invalid password. Password must contain at least 8 characters, digits, and special characters.");
                }
            }

        }

        private MUser TakeInputWithRoleSignUp()
        {
            string name = txtNameSignUp.Text;
            string password = txtPasswordSignUp.Text;
            string role = txtRoleSignUp.Text;

            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(password) && !string.IsNullOrEmpty(role))
            {
                if (role.Equals("Customer", StringComparison.OrdinalIgnoreCase))
                {
                    Customer user = new Customer(name, password, role);
                    return user;
                }
                else if (role.Equals("Admin", StringComparison.OrdinalIgnoreCase))
                {
                    Admin user = new Admin(name, password, role);
                    return user;
                }
            }

            return null;
        }

        private void linklblforSignIn_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            frmSignIn obj = new frmSignIn();
            obj.ShowDialog();
        }

        static bool IsAlphabetic(string input)
        {
            // Loop through each character in the input string
            foreach (char c in input)
            {
                // Use Char.IsLetter() method to check if the character is an alphabet
                if (!Char.IsLetter(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void txtNameSignUp_TextChanged(object sender, EventArgs e)
        {
            check = IsAlphabetic(txtNameSignUp.Text);
            if (check == true)
            {
                lblValidationSignUpName.ForeColor = Color.Green;
                lblValidationSignUpName.Text = "Valid";
            }
            else
            {
                lblValidationSignUpName.ForeColor = Color.Red;
                lblValidationSignUpName.Text = "InValid";
            }
        }

        private void txtPasswordSignUp_TextChanged(object sender, EventArgs e)
        {
            check = IsPasswordValid(txtPasswordSignUp.Text);
            if (check)
            {
                lblValidationSignUpPass.ForeColor = Color.Green;
                lblValidationSignUpPass.Text = "Valid";
            }
            else
            {
                lblValidationSignUpPass.ForeColor = Color.Red;
                lblValidationSignUpPass.Text = "Password must contain at least 8 characters, digits, and special characters";
            }
        }

        private void txtRoleSignUp_TextChanged(object sender, EventArgs e)
        {
            //if(txtRoleSignUp.Text.ToLower() == "Admin" || txtRoleSignUp.Text.ToLower() == "Customer")
            //{
            //    lblValidationSignUpRole.ForeColor = Color.Green;
            //    lblValidationSignUpRole.Text = "Valid";
            //}
            //else
            //{
            //    lblValidationSignUpRole.ForeColor = Color.Red;
            //    lblValidationSignUpRole.Text = "InValid";
            //}
        }

        
            static bool IsPasswordValid(string password)
            {
                // Check if the password length is at least 8 characters
                if (password.Length < 8)
                {
                    return false;
                }

                // Check if the password contains at least one special character and one number
                bool containsSpecialChar = false;
                bool containsNumber = false;

                foreach (char c in password)
                {
                    if (char.IsDigit(c))
                    {
                        containsNumber = true;
                    }
                    else if (char.IsSymbol(c) || char.IsPunctuation(c))
                    {
                        containsSpecialChar = true;
                    }

                    // If both conditions are met, no need to check further
                    if (containsNumber && containsSpecialChar)
                    {
                        break;
                    }
                }

                // Return true if both conditions are met (valid password), otherwise false
                return containsNumber && containsSpecialChar;
            }
        

        private void lblBackSignUp_Click(object sender, EventArgs e)
        {
            Hide();
            frmLoginMainMenu obj = new frmLoginMainMenu();
            obj.ShowDialog();
        }
    }
}
