﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    public partial class UC_AddToCart : UserControl
    {
        bool check;
        Customer customer;
        public UC_AddToCart(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            pro_duct selectedFood = (pro_duct)cmbAddCart.SelectedItem;

            if (selectedFood == null)
            {
                MessageBox.Show("Please select a valid food item.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            int quantityToAdd;
            if (!int.TryParse(txtQuantity.Text, out quantityToAdd) || quantityToAdd <= 0)
            {
                MessageBox.Show("Please enter a valid quantity greater than zero.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            int availableStock = selectedFood.get_pro_Stock();
            if (quantityToAdd > availableStock)
            {
                MessageBox.Show("Not enough stock available. Available stock: " + availableStock, "Insufficient Stock", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }


            pro_duct p = (pro_duct)cmbAddCart.SelectedItem;
            pro_duct pnew = new pro_duct(p.Pro_Name, p.Pro_Price, int.Parse(txtQuantity.Text), p.Discount);
            p.set_pro_Stock(p.Pro_Stock - pnew.Pro_Stock);
            p.Most_sold += int.Parse(txtQuantity.Text);
            customer.addbuyProduct(pnew);
            PDataLayer.store_Data_In_File();
            dataBind();
        }

        private void UC_AddToCart_Load(object sender, EventArgs e)
        {

            cmbAddCart.DataSource = null;
            cmbAddCart.DataSource = PDataLayer.getProducts();
            cmbAddCart.DisplayMember = "Pro_Name";
            cmbAddCart.Refresh();
        }
        private void dataBind()
        {
            dtaGrdCustomerViewProduct.DataSource = null;
            dtaGrdCustomerViewProduct.DataSource = customer.getBuyProducts();
            dtaGrdCustomerViewProduct.Refresh();
        }
        private void txtQuantity_TextChanged(object sender, EventArgs e)
        {
            check = IsPositiveInteger(txtQuantity.Text);

            if (check == true)
            {
                lblCartQuantity.ForeColor = Color.Green;
                lblCartQuantity.Text = "Valid";
            }
            else
            {
                lblCartQuantity.ForeColor = Color.Red;
                lblCartQuantity.Text = "InValid";
            }


        }
        static bool IsPositiveInteger(string input)
        {
            if (!int.TryParse(input, out int number))
            {
                // Parsing failed, input is not a valid integer
                return false;
            }

            // Check if the number is greater than zero
            if (number > 0)
            {
                return true;
            }

            return false;
        }

        private void btn_BackAddtoCart_Click(object sender, EventArgs e)
        {
            Hide();
            frmCustomerMainMenu obj = new frmCustomerMainMenu(customer);
            obj.ShowDialog();
        }
    }
}
