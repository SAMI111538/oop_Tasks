﻿
namespace WindowsFormsApp1bc
{
    partial class UC_ViewProduct
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dtaGrdCrud = new System.Windows.Forms.DataGridView();
            this.txtName = new System.Windows.Forms.TextBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtStock = new System.Windows.Forms.TextBox();
            this.txtDiscount = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.lblCrudName = new System.Windows.Forms.Label();
            this.lblCrudPrice = new System.Windows.Forms.Label();
            this.lblCrudStock = new System.Windows.Forms.Label();
            this.lblCrudDiscount = new System.Windows.Forms.Label();
            this.lblUdateDelete = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGrdCrud)).BeginInit();
            this.SuspendLayout();
            // 
            // dtaGrdCrud
            // 
            this.dtaGrdCrud.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dtaGrdCrud.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGrdCrud.Location = new System.Drawing.Point(581, 95);
            this.dtaGrdCrud.Name = "dtaGrdCrud";
            this.dtaGrdCrud.ReadOnly = true;
            this.dtaGrdCrud.RowHeadersWidth = 51;
            this.dtaGrdCrud.RowTemplate.Height = 24;
            this.dtaGrdCrud.Size = new System.Drawing.Size(576, 447);
            this.dtaGrdCrud.TabIndex = 0;
            this.dtaGrdCrud.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dtaGrdCrud_CellClick);
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(178, 162);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(268, 22);
            this.txtName.TabIndex = 1;
            // 
            // txtPrice
            // 
            this.txtPrice.Location = new System.Drawing.Point(178, 239);
            this.txtPrice.Name = "txtPrice";
            this.txtPrice.Size = new System.Drawing.Size(268, 22);
            this.txtPrice.TabIndex = 2;
            // 
            // txtStock
            // 
            this.txtStock.Location = new System.Drawing.Point(178, 318);
            this.txtStock.Name = "txtStock";
            this.txtStock.Size = new System.Drawing.Size(268, 22);
            this.txtStock.TabIndex = 3;
            // 
            // txtDiscount
            // 
            this.txtDiscount.Location = new System.Drawing.Point(178, 396);
            this.txtDiscount.Name = "txtDiscount";
            this.txtDiscount.Size = new System.Drawing.Size(268, 22);
            this.txtDiscount.TabIndex = 4;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(178, 508);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(93, 47);
            this.btnDelete.TabIndex = 5;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(371, 508);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(92, 47);
            this.btnUpdate.TabIndex = 6;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // lblCrudName
            // 
            this.lblCrudName.AutoSize = true;
            this.lblCrudName.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCrudName.Location = new System.Drawing.Point(23, 162);
            this.lblCrudName.Name = "lblCrudName";
            this.lblCrudName.Size = new System.Drawing.Size(143, 19);
            this.lblCrudName.TabIndex = 7;
            this.lblCrudName.Text = "Product Name";
            // 
            // lblCrudPrice
            // 
            this.lblCrudPrice.AutoSize = true;
            this.lblCrudPrice.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCrudPrice.Location = new System.Drawing.Point(23, 242);
            this.lblCrudPrice.Name = "lblCrudPrice";
            this.lblCrudPrice.Size = new System.Drawing.Size(150, 19);
            this.lblCrudPrice.TabIndex = 7;
            this.lblCrudPrice.Text = "Product  Price";
            // 
            // lblCrudStock
            // 
            this.lblCrudStock.AutoSize = true;
            this.lblCrudStock.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCrudStock.Location = new System.Drawing.Point(23, 321);
            this.lblCrudStock.Name = "lblCrudStock";
            this.lblCrudStock.Size = new System.Drawing.Size(150, 19);
            this.lblCrudStock.TabIndex = 7;
            this.lblCrudStock.Text = "Product Stock";
            // 
            // lblCrudDiscount
            // 
            this.lblCrudDiscount.AutoSize = true;
            this.lblCrudDiscount.Font = new System.Drawing.Font("Algerian", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCrudDiscount.Location = new System.Drawing.Point(45, 399);
            this.lblCrudDiscount.Name = "lblCrudDiscount";
            this.lblCrudDiscount.Size = new System.Drawing.Size(92, 19);
            this.lblCrudDiscount.TabIndex = 7;
            this.lblCrudDiscount.Text = "Discount";
            // 
            // lblUdateDelete
            // 
            this.lblUdateDelete.AutoSize = true;
            this.lblUdateDelete.Font = new System.Drawing.Font("Algerian", 25.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblUdateDelete.Location = new System.Drawing.Point(103, 40);
            this.lblUdateDelete.Name = "lblUdateDelete";
            this.lblUdateDelete.Size = new System.Drawing.Size(360, 48);
            this.lblUdateDelete.TabIndex = 8;
            this.lblUdateDelete.Text = "Update & Delete";
            // 
            // UC_ViewProduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.Controls.Add(this.lblUdateDelete);
            this.Controls.Add(this.lblCrudDiscount);
            this.Controls.Add(this.lblCrudStock);
            this.Controls.Add(this.lblCrudPrice);
            this.Controls.Add(this.lblCrudName);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.txtDiscount);
            this.Controls.Add(this.txtStock);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtName);
            this.Controls.Add(this.dtaGrdCrud);
            this.Name = "UC_ViewProduct";
            this.Size = new System.Drawing.Size(1483, 806);
            this.Load += new System.EventHandler(this.UC_ViewProduct_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dtaGrdCrud)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dtaGrdCrud;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtStock;
        private System.Windows.Forms.TextBox txtDiscount;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Label lblCrudName;
        private System.Windows.Forms.Label lblCrudPrice;
        private System.Windows.Forms.Label lblCrudStock;
        private System.Windows.Forms.Label lblCrudDiscount;
        private System.Windows.Forms.Label lblUdateDelete;
    }
}
