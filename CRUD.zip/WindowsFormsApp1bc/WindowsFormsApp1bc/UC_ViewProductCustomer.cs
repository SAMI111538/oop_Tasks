﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;

namespace WindowsFormsApp1bc
{
    
    public partial class UC_ViewProductCustomer : UserControl
    {
        public UC_ViewProductCustomer()
        {
            InitializeComponent();
        }

        private void UC_ViewProductCustomer_Load(object sender, EventArgs e)
        {
            dataBind();
        }

        private void dataBind()
        {
            dtaGrdViewProductToCustomer.DataSource = null;
            dtaGrdViewProductToCustomer.DataSource = PDataLayer.getProducts();
            dtaGrdViewProductToCustomer.Refresh();
        }

    }
}
