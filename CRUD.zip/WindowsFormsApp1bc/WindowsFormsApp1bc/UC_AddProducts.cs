﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;
using WindowsFormsApp1bc.DL;


namespace WindowsFormsApp1bc
{
    public partial class UC_AddProducts : UserControl
    {
        bool check;
        Admin admin;
        public UC_AddProducts()
        {
            InitializeComponent();
        }

        private void AddProductButton_Click(object sender, EventArgs e)
        {
            string productName = txtAddProNames.Text;

            // Check if the product name is valid (contains only alphabetic characters)
            if (!IsAlphabetic(productName))
            {
                MessageBox.Show("Invalid product name. Please enter a valid name containing only alphabetic characters.");
                return;
            }

            // Check if the product name is one of the allowed names
            List<string> allowedProductNames = new List<string>
    {
        "Shirts", "T-Shirts", "Tie", "Pants", "Socks", "Trousers"
    };

            if (!allowedProductNames.Contains(productName, StringComparer.OrdinalIgnoreCase))
            {
                MessageBox.Show("Invalid product name. Please enter one of the allowed product names (Shirts, T-Shirts, Tie, Pants, Socks, Trousers).");
                return;
            }

            // Check if the product with the same name is already added
            foreach (pro_duct product in DL.PDataLayer.getProducts())
            {
                if (string.Equals(product.Pro_Name, productName, StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show($"Product '{productName}' is already added. Please update it instead.");
                    return;
                }
            }

            double price;
            int stock;
            double discount;

            // Check if price is a positive number
            if (!double.TryParse(txtAddProPrice.Text, out price) || price <= 0)
            {
                MessageBox.Show("Invalid product price. Please enter a positive number.");
                return;
            }

            // Check if stock is a non-negative integer
            if (!int.TryParse(txtAddProStock.Text, out stock) || stock < 0)
            {
                MessageBox.Show("Invalid product stock. Please enter a non-negative integer.");
                return;
            }

            // Check if discount is in the range [1, 100]
            if (!double.TryParse(txtAddDiscount.Text, out discount) || discount < 1 || discount > 100)
            {
                MessageBox.Show("Invalid discount. Please enter a value between 1 and 100.");
                return;
            }

            pro_duct p = new pro_duct(productName, price, stock, discount);

            if (chkBxBranded.Checked)
            {
                p.IsLocal = false;
                p.set_pro_Price(p.get_pro_Price() + (p.get_pro_Price() * 0.5));
            }

            DL.PDataLayer.addProduct(p);
            DL.PDataLayer.store_Data_In_File();
            MessageBox.Show("Product added successfully in file");

        }
        

        private bool ProductExists(string productName)
        {
            foreach (pro_duct product in DL.PDataLayer.getProducts())
            {
                if (string.Equals(product.Pro_Name, productName, StringComparison.OrdinalIgnoreCase))
                {
                    return true;
                }
            }
            return false;
        }

        private void txtAddProName_TextChanged(object sender, EventArgs e)
        {
            check = IsAlphabetic(txtAddProNames.Text);
            if(check == true)
            {
                lblValidationProductName.ForeColor = Color.Green;
                lblValidationProductName.Text = "Valid";
            }
            else
            {
                lblValidationProductName.ForeColor = Color.Red;
                lblValidationProductName.Text = "InValid";
            }

        }

        static bool IsAlphabetic(string input)
        {
            // Loop through each character in the input string
            foreach (char c in input)
            {
                if (!char.IsLetter(c))
                {
                    return false;
                }
            }
            return true;
        }

        private void txtAddProPrice_TextChanged(object sender, EventArgs e)
        {
            check = IsPositiveInteger(txtAddProPrice.Text);
            if (check == true)
            {
                lblValidationProductPrice.ForeColor = Color.Green;
                lblValidationProductPrice.Text = "Valid";
            }
            else
            {
                lblValidationProductPrice.ForeColor = Color.Red;
                lblValidationProductPrice.Text = "InValid";
            }
        }

        static bool IsPositiveInteger(string input)
        {
            if (!int.TryParse(input, out int number))
            {
                // Parsing failed, input is not a valid integer
                return false;
            }

            // Check if the number is greater than zero
            if (number > 0)
            {
                return true;
            }

            return false;
        }

        private void txtAddProStock_TextChanged(object sender, EventArgs e)
        {
            check = IsPositiveInteger(txtAddProPrice.Text);
            if (check == true)
            {
                lblValidationProductStock.ForeColor = Color.Green;
                lblValidationProductStock.Text = "Valid";
            }
            else
            {
                lblValidationProductStock.ForeColor = Color.Red;
                lblValidationProductStock.Text = "InValid";
            }
        }

        private void txtAddDiscount_TextChanged(object sender, EventArgs e)
        {
            check = IsPositiveInteger(txtAddProPrice.Text);
            if (check == true)
            {
                lblValidationProductDiscount.ForeColor = Color.Green;
                lblValidationProductDiscount.Text = "Valid";
            }
            else
            {
                lblValidationProductDiscount.ForeColor = Color.Red;
                lblValidationProductDiscount.Text = "InValid";
            }
        }

        private void BackButtonToAdminMenu_Click(object sender, EventArgs e)
        {
            Hide();
            frmAdminMainMenu obj = new frmAdminMainMenu(admin);
            obj.ShowDialog();
        }

        private void tblsecondAddPro_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
