﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;

namespace WindowsFormsApp1bc
{
    public partial class MainMenu : Form
    {
        public MainMenu(Customer customer)
        {
            InitializeComponent();
            
        }

        private void UC_BillCalculate_Load(object sender, EventArgs e)
        {
        }

        
    }
}
