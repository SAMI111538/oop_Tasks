﻿
namespace WindowsFormsApp1bc
{
    partial class UC_ViewMostPopularProductCustomer
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.lblMostPopularName = new System.Windows.Forms.Label();
            this.lblMostPopularQuantity = new System.Windows.Forms.Label();
            this.lblPopularQuantity = new System.Windows.Forms.Label();
            this.lblPopularName = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_MostPopularProductCustomerBack = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 486F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btn_MostPopularProductCustomerBack, 1, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(1, 1);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.21053F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.78947F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1122, 760);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49F));
            this.tableLayoutPanel2.Controls.Add(this.lblMostPopularName, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.lblMostPopularQuantity, 0, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblPopularQuantity, 1, 1);
            this.tableLayoutPanel2.Controls.Add(this.lblPopularName, 1, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(3, 149);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 3;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 174F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 279F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(630, 608);
            this.tableLayoutPanel2.TabIndex = 5;
            // 
            // lblMostPopularName
            // 
            this.lblMostPopularName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMostPopularName.AutoSize = true;
            this.lblMostPopularName.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblMostPopularName.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostPopularName.Location = new System.Drawing.Point(92, 58);
            this.lblMostPopularName.Name = "lblMostPopularName";
            this.lblMostPopularName.Size = new System.Drawing.Size(136, 38);
            this.lblMostPopularName.TabIndex = 0;
            this.lblMostPopularName.Text = "Name : ";
            // 
            // lblMostPopularQuantity
            // 
            this.lblMostPopularQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblMostPopularQuantity.AutoSize = true;
            this.lblMostPopularQuantity.BackColor = System.Drawing.SystemColors.ControlLight;
            this.lblMostPopularQuantity.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMostPopularQuantity.Location = new System.Drawing.Point(58, 223);
            this.lblMostPopularQuantity.Name = "lblMostPopularQuantity";
            this.lblMostPopularQuantity.Size = new System.Drawing.Size(205, 38);
            this.lblMostPopularQuantity.TabIndex = 0;
            this.lblMostPopularQuantity.Text = "Quantity : ";
            // 
            // lblPopularQuantity
            // 
            this.lblPopularQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPopularQuantity.AutoSize = true;
            this.lblPopularQuantity.Font = new System.Drawing.Font("Algerian", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopularQuantity.ForeColor = System.Drawing.Color.Red;
            this.lblPopularQuantity.Location = new System.Drawing.Point(475, 217);
            this.lblPopularQuantity.Name = "lblPopularQuantity";
            this.lblPopularQuantity.Size = new System.Drawing.Size(0, 49);
            this.lblPopularQuantity.TabIndex = 2;
            // 
            // lblPopularName
            // 
            this.lblPopularName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblPopularName.AutoSize = true;
            this.lblPopularName.Font = new System.Drawing.Font("Algerian", 26F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPopularName.ForeColor = System.Drawing.Color.Red;
            this.lblPopularName.Location = new System.Drawing.Point(475, 53);
            this.lblPopularName.Name = "lblPopularName";
            this.lblPopularName.Size = new System.Drawing.Size(0, 49);
            this.lblPopularName.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ControlLight;
            this.label1.Font = new System.Drawing.Font("Algerian", 26F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(43, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(549, 49);
            this.label1.TabIndex = 0;
            this.label1.Text = "Most Popular Product";
            // 
            // btn_MostPopularProductCustomerBack
            // 
            this.btn_MostPopularProductCustomerBack.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_MostPopularProductCustomerBack.Font = new System.Drawing.Font("Algerian", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_MostPopularProductCustomerBack.Location = new System.Drawing.Point(802, 429);
            this.btn_MostPopularProductCustomerBack.Name = "btn_MostPopularProductCustomerBack";
            this.btn_MostPopularProductCustomerBack.Size = new System.Drawing.Size(154, 48);
            this.btn_MostPopularProductCustomerBack.TabIndex = 2;
            this.btn_MostPopularProductCustomerBack.Text = "Back";
            this.btn_MostPopularProductCustomerBack.UseVisualStyleBackColor = true;
            this.btn_MostPopularProductCustomerBack.Click += new System.EventHandler(this.btn_MostPopularProductCustomerBack_Click);
            // 
            // UC_ViewMostPopularProductCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "UC_ViewMostPopularProductCustomer";
            this.Size = new System.Drawing.Size(1125, 763);
            this.Load += new System.EventHandler(this.UC_ViewMostPopularProductCustomer_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_MostPopularProductCustomerBack;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label lblMostPopularName;
        private System.Windows.Forms.Label lblMostPopularQuantity;
        private System.Windows.Forms.Label lblPopularQuantity;
        private System.Windows.Forms.Label lblPopularName;
    }
}
