﻿using WindowsFormsApp1bc.DL;
using WindowsFormsApp1bc.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1bc.BL
{
    public class Customer : MUser //Child Class for the Customer with the Parent of the MUser
    {
        //Attributes of the Class
        private List<pro_duct> Bought_Products= new List<pro_duct>();
        private string email;
        private string id;
        private string Address;
        private string city;
        private string Contact_Number;
        

        public List<pro_duct> getBuyProducts()//Every Customer's OrderList
        {
            return Bought_Products;
        }
        public Customer(string name, string password, string role) : base(name, password, role)//Constructors for the Customers Input
        {
        }
        public Customer(string name, string password,string email, string id,string Address,string ContactNumber,string City) : base(name, password)//Constructors for Adding Info of the Every New Coming Customers
        {
            this.Address = Address;
            this.email = email;
            this.id = id;
            this.city = City;
            this.Address = Address;
            this.Contact_Number = ContactNumber;
        }

        public double calculateBill()
        {
            double bill = 0;
            double price = 0;
            foreach (var i in Bought_Products)
            {
                if(i.getDiscount() != 0)
                {
                   price = i.Pro_Stock * i.Pro_Price - (i.getDiscount() * 0.01F);
                }
                else
                {
                    price += i.Pro_Stock * i.Pro_Price;
                }
                bill = bill + price;
               
            }
            return bill;
        }

        //Getter Setter for Address
        public string getAddress()
        {
            return Address;
        }
        public void setAddress(string Address)
        {
            this.Address = Address;
        }
        //Getter Setter for Mail
        public string getMail()
        {
            return email;
        }
        public void setMail(string email)
        {
            this.email = email;
        }
        //Getter Setter for ID
        public string getID()
        {
            return id;
        }
        public void setID(string id)
        {
            this.id = id;
        }
        //Getter Setter For Customer City
        public string getCity()
        {
            return city;
        }
        public void setCity(string city)
        {
            this.city = city;
        }
        
        //Getter Setter For Customer Contact No.
        public string getContactNumber()
        {
            return Contact_Number;;
        }
        public void setContactNumber(string Contact_Number)
        {
            this.Contact_Number = Contact_Number;
        }
        //Default Constructor for the Customer Class
        public Customer() {  }

        //Constructor for the Name And Password
        public Customer(string name, string password) : base()
        {
            this.name = name;
            this.password = password;
        }
        //Getter Setter For the List of the Order
        public void addbuyProduct(pro_duct F)
        {
            Bought_Products.Add(F);
        }
        
        public List<pro_duct> viewAllProducts()
        {
            return Bought_Products;
        }

        //Polymorphism for Function taking Role As Input
        //Role GEtter Setter
        public override void setRole(string role)
        {
            this.role = "customer";
        }
        public override string getRole()
        {
            return role;
        }
        public void removeOrderedProduct(pro_duct p)
        {
            Bought_Products.Remove(p);
        }
    }
}
