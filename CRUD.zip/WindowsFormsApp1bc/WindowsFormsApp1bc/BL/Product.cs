﻿using WindowsFormsApp1bc.DL;
using WindowsFormsApp1bc.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1bc.BL
{
    public class pro_duct//Products Class
    {
        //Attributes of the class
        private string pro_Name;
        private double pro_Price;
        private int pro_Stock;
        private double discount;
        private bool isLocal = true;
        private int most_sold;

        public int Most_sold { get => most_sold; set => most_sold = value; }
        public string Pro_Name { get => pro_Name; set => pro_Name = value; }
        public double Pro_Price { get => pro_Price; set => pro_Price = value; }
        public int Pro_Stock { get => pro_Stock; set => pro_Stock = value; }
        public double Discount { get => discount; set => discount = value; }
        public bool IsLocal { get => isLocal; set => isLocal = value; }

        public pro_duct(string pro_Name, double pro_Price, int pro_Stock, double discount)//Constructors of the class ALL Attributes
        {
            this.discount = discount;
            this.pro_Name = pro_Name;
            this.pro_Price = pro_Price;
            this.pro_Stock = pro_Stock;
        }
        public pro_duct()//Default Constructor of the Class
        {

        }
        //Getter Setter of the Name
        public void set_pro_Name(string name)
        {
            this.pro_Name = name;
        }
        public string get_pro_Name()
        {
            return pro_Name;
        }

        //Getter Setter of the Price
        public void set_pro_Price(double pro_Price)
        {
            this.pro_Price = pro_Price;
        }
        public double get_pro_Price()
        {
            return pro_Price;
        }
        //Getter Setter of the Stock
        public void set_pro_Stock(int pro_Stock)
        {
            this.pro_Stock = pro_Stock;
        }
        public int get_pro_Stock()
        {
            return pro_Stock;
        }
        
        //Getter Setter of the Discount
        public void setDiscount(double discount)
        {
            this.discount = discount;
        }
        public double getDiscount()
        {
            return discount;
        }

        //Constructors of the Class 2 Attributes of [Price,Stock]
        public pro_duct(int pro_Price, int pro_Stock)
        {
            this.pro_Price = pro_Price;
            this.pro_Stock = pro_Stock;
        }
        //Constructors of the Class 2 Attributes of [Name,Price]
        public pro_duct(string pro_Name, int pro_Price)
        {
            this.pro_Name = pro_Name;
            this.pro_Price = pro_Price;
        }


        //GETTER SETTER OF THE GET COUNTRY
        public bool getCountry()
        {
            return isLocal;
        }
        public void setCountry(bool isLocal)
        {
            this.isLocal = isLocal;
        }


    }
}
