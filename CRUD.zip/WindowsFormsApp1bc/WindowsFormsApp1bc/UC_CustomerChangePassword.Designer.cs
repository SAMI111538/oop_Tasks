﻿
namespace WindowsFormsApp1bc
{
    partial class UC_CustomerChangePassword
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblCusChangePassword = new System.Windows.Forms.Label();
            this.tblChangePassword = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lblCusConfirmPassword = new System.Windows.Forms.Label();
            this.lblCusOldPassword = new System.Windows.Forms.Label();
            this.lblCusNewPAssword = new System.Windows.Forms.Label();
            this.txtCusNewPassword = new System.Windows.Forms.TextBox();
            this.txtOldCusPassword = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtCusConfirmPassword = new System.Windows.Forms.TextBox();
            this.btnCusChangePassword = new System.Windows.Forms.Button();
            this.lblValidationCusOldPass = new System.Windows.Forms.Label();
            this.lblValidationCusNewPass = new System.Windows.Forms.Label();
            this.lblValidationCusConfirmPass = new System.Windows.Forms.Label();
            this.tblChangePassword.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblCusChangePassword
            // 
            this.lblCusChangePassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCusChangePassword.AutoSize = true;
            this.lblCusChangePassword.BackColor = System.Drawing.Color.Transparent;
            this.lblCusChangePassword.Font = new System.Drawing.Font("Algerian", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusChangePassword.Location = new System.Drawing.Point(387, 50);
            this.lblCusChangePassword.Name = "lblCusChangePassword";
            this.lblCusChangePassword.Size = new System.Drawing.Size(433, 48);
            this.lblCusChangePassword.TabIndex = 0;
            this.lblCusChangePassword.Text = "Change Password";
            // 
            // tblChangePassword
            // 
            this.tblChangePassword.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tblChangePassword.ColumnCount = 1;
            this.tblChangePassword.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tblChangePassword.Controls.Add(this.lblCusChangePassword, 0, 0);
            this.tblChangePassword.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.tblChangePassword.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblChangePassword.Location = new System.Drawing.Point(0, 0);
            this.tblChangePassword.Name = "tblChangePassword";
            this.tblChangePassword.RowCount = 2;
            this.tblChangePassword.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 19.29596F));
            this.tblChangePassword.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 80.70404F));
            this.tblChangePassword.Size = new System.Drawing.Size(1208, 767);
            this.tblChangePassword.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 464F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 298F));
            this.tableLayoutPanel1.Controls.Add(this.lblCusConfirmPassword, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.lblCusOldPassword, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblCusNewPAssword, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtCusNewPassword, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtOldCusPassword, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.label2, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtCusConfirmPassword, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.btnCusChangePassword, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.lblValidationCusOldPass, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.lblValidationCusNewPass, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.lblValidationCusConfirmPass, 2, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 151);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 5;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 47.14286F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 52.85714F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 103F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 243F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1202, 613);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // lblCusConfirmPassword
            // 
            this.lblCusConfirmPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCusConfirmPassword.AutoSize = true;
            this.lblCusConfirmPassword.Font = new System.Drawing.Font("Algerian", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusConfirmPassword.Location = new System.Drawing.Point(87, 201);
            this.lblCusConfirmPassword.Name = "lblCusConfirmPassword";
            this.lblCusConfirmPassword.Size = new System.Drawing.Size(266, 30);
            this.lblCusConfirmPassword.TabIndex = 0;
            this.lblCusConfirmPassword.Text = "Confirm Password";
            // 
            // lblCusOldPassword
            // 
            this.lblCusOldPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCusOldPassword.AutoSize = true;
            this.lblCusOldPassword.Font = new System.Drawing.Font("Algerian", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusOldPassword.Location = new System.Drawing.Point(117, 24);
            this.lblCusOldPassword.Name = "lblCusOldPassword";
            this.lblCusOldPassword.Size = new System.Drawing.Size(205, 30);
            this.lblCusOldPassword.TabIndex = 0;
            this.lblCusOldPassword.Text = "Old Password";
            // 
            // lblCusNewPAssword
            // 
            this.lblCusNewPAssword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCusNewPAssword.AutoSize = true;
            this.lblCusNewPAssword.Font = new System.Drawing.Font("Algerian", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCusNewPAssword.Location = new System.Drawing.Point(114, 107);
            this.lblCusNewPAssword.Name = "lblCusNewPAssword";
            this.lblCusNewPAssword.Size = new System.Drawing.Size(211, 30);
            this.lblCusNewPAssword.TabIndex = 2;
            this.lblCusNewPAssword.Text = "New Password";
            // 
            // txtCusNewPassword
            // 
            this.txtCusNewPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCusNewPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCusNewPassword.Location = new System.Drawing.Point(499, 103);
            this.txtCusNewPassword.Name = "txtCusNewPassword";
            this.txtCusNewPassword.Size = new System.Drawing.Size(346, 38);
            this.txtCusNewPassword.TabIndex = 3;
            this.txtCusNewPassword.TextChanged += new System.EventHandler(this.txtCusNewPassword_TextChanged);
            // 
            // txtOldCusPassword
            // 
            this.txtOldCusPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtOldCusPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOldCusPassword.Location = new System.Drawing.Point(499, 20);
            this.txtOldCusPassword.Name = "txtOldCusPassword";
            this.txtOldCusPassword.Size = new System.Drawing.Size(346, 38);
            this.txtOldCusPassword.TabIndex = 3;
            this.txtOldCusPassword.TextChanged += new System.EventHandler(this.txtOldCusPassword_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(3, 266);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 1;
            // 
            // txtCusConfirmPassword
            // 
            this.txtCusConfirmPassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtCusConfirmPassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCusConfirmPassword.Location = new System.Drawing.Point(499, 197);
            this.txtCusConfirmPassword.Name = "txtCusConfirmPassword";
            this.txtCusConfirmPassword.Size = new System.Drawing.Size(346, 38);
            this.txtCusConfirmPassword.TabIndex = 4;
            this.txtCusConfirmPassword.TextChanged += new System.EventHandler(this.txtCusConfirmPassword_TextChanged);
            // 
            // btnCusChangePassword
            // 
            this.btnCusChangePassword.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btnCusChangePassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCusChangePassword.Location = new System.Drawing.Point(608, 288);
            this.btnCusChangePassword.Name = "btnCusChangePassword";
            this.btnCusChangePassword.Size = new System.Drawing.Size(128, 58);
            this.btnCusChangePassword.TabIndex = 5;
            this.btnCusChangePassword.Text = "Change";
            this.btnCusChangePassword.UseVisualStyleBackColor = true;
            this.btnCusChangePassword.Click += new System.EventHandler(this.btnCusChangePassword_Click);
            // 
            // lblValidationCusOldPass
            // 
            this.lblValidationCusOldPass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationCusOldPass.AutoSize = true;
            this.lblValidationCusOldPass.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationCusOldPass.Location = new System.Drawing.Point(907, 28);
            this.lblValidationCusOldPass.Name = "lblValidationCusOldPass";
            this.lblValidationCusOldPass.Size = new System.Drawing.Size(0, 22);
            this.lblValidationCusOldPass.TabIndex = 6;
            // 
            // lblValidationCusNewPass
            // 
            this.lblValidationCusNewPass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationCusNewPass.AutoSize = true;
            this.lblValidationCusNewPass.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationCusNewPass.Location = new System.Drawing.Point(907, 111);
            this.lblValidationCusNewPass.Name = "lblValidationCusNewPass";
            this.lblValidationCusNewPass.Size = new System.Drawing.Size(0, 22);
            this.lblValidationCusNewPass.TabIndex = 6;
            // 
            // lblValidationCusConfirmPass
            // 
            this.lblValidationCusConfirmPass.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.lblValidationCusConfirmPass.AutoSize = true;
            this.lblValidationCusConfirmPass.Font = new System.Drawing.Font("Algerian", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblValidationCusConfirmPass.Location = new System.Drawing.Point(907, 205);
            this.lblValidationCusConfirmPass.Name = "lblValidationCusConfirmPass";
            this.lblValidationCusConfirmPass.Size = new System.Drawing.Size(0, 22);
            this.lblValidationCusConfirmPass.TabIndex = 6;
            // 
            // UC_CustomerChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tblChangePassword);
            this.Name = "UC_CustomerChangePassword";
            this.Size = new System.Drawing.Size(1208, 767);
            this.tblChangePassword.ResumeLayout(false);
            this.tblChangePassword.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblCusChangePassword;
        private System.Windows.Forms.TableLayoutPanel tblChangePassword;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label lblCusConfirmPassword;
        private System.Windows.Forms.Label lblCusOldPassword;
        private System.Windows.Forms.Label lblCusNewPAssword;
        private System.Windows.Forms.TextBox txtCusNewPassword;
        private System.Windows.Forms.TextBox txtOldCusPassword;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtCusConfirmPassword;
        private System.Windows.Forms.Button btnCusChangePassword;
        private System.Windows.Forms.Label lblValidationCusOldPass;
        private System.Windows.Forms.Label lblValidationCusNewPass;
        private System.Windows.Forms.Label lblValidationCusConfirmPass;
    }
}
