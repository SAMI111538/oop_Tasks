﻿
namespace WindowsFormsApp1bc
{
    partial class UC_AddToCart
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.lblCartName = new System.Windows.Forms.Label();
            this.lblCartQuantity = new System.Windows.Forms.Label();
            this.cmbAddCart = new System.Windows.Forms.ComboBox();
            this.btn_addToCart = new System.Windows.Forms.Button();
            this.txtQuantity = new System.Windows.Forms.TextBox();
            this.btn_BackAddtoCart = new System.Windows.Forms.Button();
            this.dtaGrdCustomerViewProduct = new System.Windows.Forms.DataGridView();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGrdCustomerViewProduct)).BeginInit();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.dtaGrdCustomerViewProduct, 1, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 1;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(895, 634);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.label1, 0, 0);
            this.tableLayoutPanel2.Controls.Add(this.tableLayoutPanel3, 0, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(2, 2);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 17.70026F));
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 82.29974F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(442, 629);
            this.tableLayoutPanel2.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Algerian", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(99, 36);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(244, 39);
            this.label1.TabIndex = 0;
            this.label1.Text = "ADD TO CART";
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 2;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 29.62329F));
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 70.37671F));
            this.tableLayoutPanel3.Controls.Add(this.lblCartName, 0, 0);
            this.tableLayoutPanel3.Controls.Add(this.lblCartQuantity, 0, 1);
            this.tableLayoutPanel3.Controls.Add(this.cmbAddCart, 1, 0);
            this.tableLayoutPanel3.Controls.Add(this.btn_addToCart, 1, 2);
            this.tableLayoutPanel3.Controls.Add(this.txtQuantity, 1, 1);
            this.tableLayoutPanel3.Controls.Add(this.btn_BackAddtoCart, 0, 2);
            this.tableLayoutPanel3.Location = new System.Drawing.Point(2, 113);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 4;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.93168F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.06832F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 84F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 276F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(438, 513);
            this.tableLayoutPanel3.TabIndex = 1;
            // 
            // lblCartName
            // 
            this.lblCartName.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCartName.AutoSize = true;
            this.lblCartName.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCartName.Location = new System.Drawing.Point(34, 28);
            this.lblCartName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCartName.Name = "lblCartName";
            this.lblCartName.Size = new System.Drawing.Size(61, 21);
            this.lblCartName.TabIndex = 0;
            this.lblCartName.Text = "Name";
            // 
            // lblCartQuantity
            // 
            this.lblCartQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblCartQuantity.AutoSize = true;
            this.lblCartQuantity.Font = new System.Drawing.Font("Algerian", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCartQuantity.Location = new System.Drawing.Point(15, 104);
            this.lblCartQuantity.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblCartQuantity.Name = "lblCartQuantity";
            this.lblCartQuantity.Size = new System.Drawing.Size(99, 21);
            this.lblCartQuantity.TabIndex = 0;
            this.lblCartQuantity.Text = "Quantity";
            // 
            // cmbAddCart
            // 
            this.cmbAddCart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cmbAddCart.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbAddCart.FormattingEnabled = true;
            this.cmbAddCart.Location = new System.Drawing.Point(198, 22);
            this.cmbAddCart.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.cmbAddCart.Name = "cmbAddCart";
            this.cmbAddCart.Size = new System.Drawing.Size(171, 32);
            this.cmbAddCart.TabIndex = 1;
            // 
            // btn_addToCart
            // 
            this.btn_addToCart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_addToCart.Font = new System.Drawing.Font("Algerian", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_addToCart.Location = new System.Drawing.Point(205, 166);
            this.btn_addToCart.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_addToCart.Name = "btn_addToCart";
            this.btn_addToCart.Size = new System.Drawing.Size(157, 55);
            this.btn_addToCart.TabIndex = 2;
            this.btn_addToCart.Text = "ADD TO CART";
            this.btn_addToCart.UseVisualStyleBackColor = true;
            this.btn_addToCart.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtQuantity
            // 
            this.txtQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.txtQuantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantity.Location = new System.Drawing.Point(199, 100);
            this.txtQuantity.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtQuantity.Name = "txtQuantity";
            this.txtQuantity.Size = new System.Drawing.Size(169, 29);
            this.txtQuantity.TabIndex = 3;
            this.txtQuantity.TextChanged += new System.EventHandler(this.txtQuantity_TextChanged);
            // 
            // btn_BackAddtoCart
            // 
            this.btn_BackAddtoCart.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.btn_BackAddtoCart.Font = new System.Drawing.Font("Algerian", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_BackAddtoCart.Location = new System.Drawing.Point(10, 173);
            this.btn_BackAddtoCart.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btn_BackAddtoCart.Name = "btn_BackAddtoCart";
            this.btn_BackAddtoCart.Size = new System.Drawing.Size(109, 42);
            this.btn_BackAddtoCart.TabIndex = 4;
            this.btn_BackAddtoCart.Text = "BACK";
            this.btn_BackAddtoCart.UseVisualStyleBackColor = true;
            this.btn_BackAddtoCart.Click += new System.EventHandler(this.btn_BackAddtoCart_Click);
            // 
            // dtaGrdCustomerViewProduct
            // 
            this.dtaGrdCustomerViewProduct.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dtaGrdCustomerViewProduct.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dtaGrdCustomerViewProduct.Location = new System.Drawing.Point(449, 2);
            this.dtaGrdCustomerViewProduct.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.dtaGrdCustomerViewProduct.Name = "dtaGrdCustomerViewProduct";
            this.dtaGrdCustomerViewProduct.RowHeadersWidth = 51;
            this.dtaGrdCustomerViewProduct.RowTemplate.Height = 24;
            this.dtaGrdCustomerViewProduct.Size = new System.Drawing.Size(444, 630);
            this.dtaGrdCustomerViewProduct.TabIndex = 1;
            // 
            // UC_AddToCart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tableLayoutPanel1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "UC_AddToCart";
            this.Size = new System.Drawing.Size(895, 634);
            this.Load += new System.EventHandler(this.UC_AddToCart_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel3.ResumeLayout(false);
            this.tableLayoutPanel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dtaGrdCustomerViewProduct)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.DataGridView dtaGrdCustomerViewProduct;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Label lblCartName;
        private System.Windows.Forms.Label lblCartQuantity;
        private System.Windows.Forms.ComboBox cmbAddCart;
        private System.Windows.Forms.Button btn_addToCart;
        private System.Windows.Forms.TextBox txtQuantity;
        private System.Windows.Forms.Button btn_BackAddtoCart;
    }
}
