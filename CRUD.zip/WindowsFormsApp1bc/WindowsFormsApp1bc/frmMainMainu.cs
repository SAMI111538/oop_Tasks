﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1bc
{
    public partial class frmLoginMainMenu : Form
    {
        public frmLoginMainMenu()
        {
            InitializeComponent();
        }

        private void btn_SignUP_Click(object sender, EventArgs e)
        {
            Hide();
            frmSignUp obj = new frmSignUp();
            obj.ShowDialog();
        }

        private void btn_SignIn_Click(object sender, EventArgs e)
        {
            Hide();
            frmSignIn obj = new frmSignIn();
            obj.ShowDialog();
        }

    }
}
