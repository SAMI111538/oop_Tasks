﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1bc.BL;

namespace WindowsFormsApp1bc
{
    
    public partial class UC_AddFeedBack : UserControl
    {
        Customer customer;
        public UC_AddFeedBack(Customer customer)
        {
            InitializeComponent();
            this.customer = customer;
        }

        private void btn_AddFeedback_Click(object sender, EventArgs e)
        {
            string feedbackText = txtCustomerAddFeedback.Text.Trim();

            if (string.IsNullOrWhiteSpace(feedbackText))
            {
                MessageBox.Show("Please enter your feedback.", "Empty Feedback", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Save the customer feedback to the "feedback.txt" file
            SaveFeedbackToFile(feedbackText);
            MessageBox.Show("Feedback added successfully.");
        }

        private void SaveFeedbackToFile(string feedbackText)
        {
            // Write the feedback to the "feedback.txt" file
            using (StreamWriter sw = new StreamWriter("feedback.txt", true))
            {
                sw.WriteLine(feedbackText);
            }
        }

        private void cmdAdminAddNoodlesBack_Click(object sender, EventArgs e)
        {
            Hide();
            frmCustomerMainMenu obj = new frmCustomerMainMenu(customer);
            obj.ShowDialog();
        }
    }
}
