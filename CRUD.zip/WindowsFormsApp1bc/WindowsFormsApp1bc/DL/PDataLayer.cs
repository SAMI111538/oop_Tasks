﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WindowsFormsApp1bc.BL;

namespace WindowsFormsApp1bc.DL
{
    public class PDataLayer//DataLAyer for the produccts
    {
        private static List<pro_duct> products = new List<pro_duct>();//Product lst for add the products in the list
        public static void addProduct(pro_duct F)//Funtion to Add products in the list
        {
            products.Add(F);
        }
        public static void RemoveParticularProduct(int index)//Funtion to Remove products in the list
        {
            products.RemoveAt(index);
        }

        public static void RemoveProduct(pro_duct p)//Funtion to Remove products in the list
        {
            products.Remove(p);
        }
        public static void UpdateProduct(pro_duct p,pro_duct n)//Funtion to Remove products in the list
        {
            p.Pro_Name = n.Pro_Name;
            p.Pro_Price = n.Pro_Price;
            p.Pro_Stock = n.Pro_Stock;
            p.Discount = n.Discount;
        }
        public static List<pro_duct> getProducts()//Funtion to get product's list
        {
            return products;
        }
        public static List<pro_duct> sortByPrice()//Funtion to Sort products in the list by Price
        {
            List<pro_duct> temp = products.OrderByDescending(o => o.get_pro_Price()).ToList();
            return temp;
        }

        public static void storeProductDataInList(pro_duct pro)//Funtion to Store products in the list
        {
            products.Add(pro);
        }

        public static pro_duct sortBySoldedItem()//Funtion to Sort products in the list by Price
        {
            List<pro_duct> temp = products.OrderByDescending(o => o.Most_sold).ToList();
            return temp[0];
        }


        public static void store_Data_In_File()//Funtion to Store product's Data in the File
        {
            StreamWriter myfile = new StreamWriter("Product.txt");
            foreach (var i in products)
            {
                myfile.WriteLine(i.Pro_Name + "," + i.Pro_Price + "," + i.Pro_Stock + "," + i.Most_sold + "," + i.Discount);
            }
            myfile.Flush();
            myfile.Close();
        }
        public static bool readProductData(string path1)//Funtion to Read products's Data in the from the File
        {
            if (File.Exists(path1))
            {
                StreamReader fileVariable = new StreamReader(path1);
                string record;
                while ((record = fileVariable.ReadLine()) != null)
                {
                    string[] splittedRecord = record.Split(',');
                    string pro_Name = splittedRecord[0];
                    double pro_Price = double.Parse(splittedRecord[1]);
                    int pro_Stock = int.Parse(splittedRecord[2]);
                    int pro_Sold = int.Parse((splittedRecord[3]));
                    double discount = double.Parse(splittedRecord[4]);
                    pro_duct pro = new pro_duct(pro_Name, pro_Price, pro_Stock, discount);
                    pro.Most_sold = pro_Sold;
                    storeProductDataInList(pro);
                }
                fileVariable.Close();
                return true;
            }
            return false;
        }
    }
}
