﻿using WindowsFormsApp1bc.DL;
using WindowsFormsApp1bc.BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1bc.DL
{
    class AdminDL
    {
        private static List<string> feedbacks = new List<string>();

        public static List<string> Feedbacks { get => feedbacks; set => feedbacks = value; }

        public void addFeedback(string F) //functon to add object in list
        {
            Feedbacks.Add(F);
        }
    }
}
